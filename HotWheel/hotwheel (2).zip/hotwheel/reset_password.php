<?php
session_start();
include "db.php";

$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $password = $_POST['password'];

    if (strlen($password) < 6) {
        $message = "Password must be at least 6 characters.";
    } else {
        $new_pass = password_hash($password, PASSWORD_DEFAULT);
        $email = $_SESSION['reset_email'];

        $stmt = $conn->prepare("UPDATE users SET password_hash=? WHERE email=?");
        $stmt->bind_param("ss", $new_pass, $email);

        if ($stmt->execute()) {
            $message = "Password updated successfully. <a href='login.php' class='login-link'>Login</a>";
            session_destroy();
        } else {
            $message = "Something went wrong.";
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f6f8;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
            width: 350px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
            color: black;
        }
        .password-wrapper {
            position: relative;
            width: 100%;
        }
        input[type="password"], input[type="text"] {
            width: 100%;
            padding: 12px 40px 12px 12px; /* space for eye */
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
            box-sizing: border-box;
            font-size: 16px;
            outline: none;
        }
        .toggle-eye {
            position: absolute;
            top: 50%;
            right: 12px;
            transform: translateY(-50%);
            cursor: pointer;
            font-size: 18px;
            color: #888;
        }
        button {
            width: 100%;
            background: #E95B5BFF;
            border: none;
            padding: 12px;
            color: white;
            font-size: 16px;
            border-radius: 25px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background: #ECE955FF;
            color: white;
        }
        p {
            margin-top: 15px;
            font-size: 14px;
        }
        p.error {
            color: red;
        }
        p.success {
            color: green;
        }
        a.login-link {
            color: #E95B5BFF;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Reset Password</h2>
        <form method="POST" onsubmit="return validatePassword()">
            <div class="password-wrapper">
                <input type="password" name="password" id="password" placeholder="New Password" required>
                <span class="toggle-eye" onclick="togglePassword()">👁</span>
            </div>
            <p id="passwordError" class="error" style="display:none;">Password must be at least 6 characters.</p>
            <button type="submit">Update Password</button>
        </form>
        <p class="<?php echo (strpos($message, 'successfully') !== false) ? 'success' : 'error'; ?>">
            <?php echo $message; ?>
        </p>
    </div>

    <script>
    function validatePassword() {
        const password = document.getElementById("password").value.trim();
        const errorMsg = document.getElementById("passwordError");

        if (password.length < 6) {
            errorMsg.style.display = "block";
            return false;
        } else {
            errorMsg.style.display = "none";
            return true;
        }
    }

    function togglePassword() {
        const passwordField = document.getElementById("password");
        const eyeIcon = document.querySelector(".toggle-eye");

        if (passwordField.type === "password") {
            passwordField.type = "text";
            eyeIcon.textContent = "👁";
        } else {
            passwordField.type = "password";
            eyeIcon.textContent = "👁";
        }
    }
    </script>
</body>
</html>
