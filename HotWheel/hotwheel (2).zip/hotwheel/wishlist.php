<?php
session_start();
include "db.php";

$wishlist = $_SESSION['wishlist'] ?? [];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Your Wishlist</title>
    <style>
       /* Reset and layout fix */
        html, body {
            margin: 0;
            padding: 0;
            height: 100%;
        }

        body {
            font-family: Arial, sans-serif;
            display: flex;
            flex-direction: column;
            min-height: 100vh; /* ensures footer stays at bottom */
        }

        main {
            flex: 1; /* pushes footer down */
        }

        /* Navbar */
        .navbar {
            background: linear-gradient(to bottom, #E95B5BFF, #F2D666FF);
            display: flex; align-items: center; justify-content: space-between;
            padding: 10px 20px; flex-wrap: wrap; position: relative;
        }
        .navbar-logo img { height: 70px; object-fit:contain; }
        .navbar-links { display: flex; gap: 20px; font-size: 16px; flex-wrap: wrap; position: relative; }
        .navbar-links a { color: black; text-decoration: none; }
        .navbar-links a:hover { color: white; }
        .user-info { display: flex; align-items: center; gap: 12px; font-size: 16px; flex-wrap: wrap; }
        .user-info a { color: black; text-decoration: none; }
        .user-info a:hover { color: white; }
        .menu-toggle { display: none; font-size: 28px; cursor: pointer; background:none; border:none; }

        /* Dropdown */
        .dropdown { position: relative; }
        .dropdown-content {
            display: none;
            position: absolute;
            top: 100%; left: 0;
            background-color: #fff;
            min-width: 180px;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 100;
        }
        .dropdown-content a {
            display: block;
            padding: 10px;
            color: black;
            text-decoration: none;
            font-size: 15px;
        }
        .dropdown-content a:hover {
            background: #E95B5BFF; color: white;
        }
        .dropdown:hover .dropdown-content { display: block; }

        .h {
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }

        table {
            border-collapse: collapse;
            width: 90%;
            margin: auto;
            background-color: #fff;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 15px;
            text-align: center;
        }

        th {
            background-color: #f2f2f2;
            font-weight: bold;
            color: #555;
        }

        td img {
            max-width: 80px;
            border-radius: 5px;
        }

        .remove-btn {
            padding: 8px 16px;
            background-color:#E95B5BFF ;
            color: white;
            cursor: pointer;
            border-radius: 5px;
            transition: all 0.3s ease;
            border:none;
        }

        .remove-btn:hover {
            background-color: #ECE955FF;
            color: white;
        }

        .pp {
            text-align: center;
            font-size: 18px;
        }
        /* Footer */
.footer {
    background: linear-gradient(to bottom, #F2D666FF, #E95B5BFF);
    color: black;
    padding: 40px 20px;
    margin-top: 2%; /* ✅ fix: ensures footer sticks to bottom without gap */
}

.footer-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    max-width: 1200px;
    margin: auto;
}

.footer-box { flex: 1 1 200px; margin: 10px 20px; }
.footer-box h3 { font-size: 20px; margin-bottom: 10px; }
.footer-box p, .footer-box li { font-size: 16px; line-height: 1.6; }
.footer-box ul { list-style: none; padding: 0; }
.footer-box ul li a { text-decoration: none; color: black; }
.footer-box ul li a:hover { color: white; }

.footer-socials { display: flex; gap: 15px; margin-top: 10px; }
.footer-socials img { width: 28px; height: 28px; transition: transform 0.3s ease; }
.footer-socials img:hover { transform: scale(1.1); }

.footer-bottom { text-align: center; padding-top: 20px; border-top: 1px solid #444; margin-top: 30px; }
.footer-bottom p { margin: 0; color: black; }

        /* Scroll to Top */
        #scrollTopBtn {
            position: fixed; bottom: 25px; right: 25px;
            background: #E95B5BFF; color: white;
            border: none; padding: 12px 16px; border-radius: 50%;
            font-size: 20px; cursor: pointer; display: none;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            z-index: 99;
        }
        #scrollTopBtn:hover { background: #F2D666FF; color: black; }
/* Cart badge styling */
.cart-link {
    position: relative;
    display: inline-block;
}

.cart-count {
    background: red;
    color: white;
    font-size: 14px;
    font-weight: bold;
    padding: 2px 8px;
    border-radius: 50%;
    margin-left: 5px;
    display: inline-block;
    animation: pop 0.5s ease;
}
/* Bounce/Pop animation */
@keyframes pop {
    0% { transform: scale(0.5); opacity: 0; }
    50% { transform: scale(1.3); opacity: 1; }
    100% { transform: scale(1); }
}

    </style>
</head>
<body>
<!-- Navbar -->
<div class="navbar">
    <div class="navbar-logo">
        <a href="index.php"><img src="images/ht.png" alt="Logo"></a>    
    </div>
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    <div class="navbar-links" id="menuLinks">
        <a href="index.php">Home</a>
        <!-- ✅ Cart with count (only show number if > 0) -->
        <?php
        $cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
        ?>
        <a href="cart.php" class="cart-link">
            Cart 
            <?php if ($cart_count > 0): ?>
                <span class="cart-count"><?= $cart_count ?></span>
            <?php endif; ?>
        </a>
           <a href="wishlist.php">Wishlist</a>
                      <a href="products.php">Products</a>

        <!-- ✅ Categories Dropdown -->
        <div class="dropdown">
            <a href="javascript:void(0)">Categories ▾</a>
            <div class="dropdown-content">
                <?php
                $cat_result = $conn->query("SELECT * FROM categories");
                if ($cat_result->num_rows > 0) {
                    while ($row = $cat_result->fetch_assoc()) {
                        echo "<a href='index.php?category_id=" . $row['id'] . "#categories'>" . htmlspecialchars($row['name']) . "</a>";
                    }
                } else {
                    echo "<a href='#'>No Categories</a>";
                }
                ?>
            </div>
        </div>

               <!-- ✅ Contact Us scroll -->
        <a href="index.php#contactSection">Contact Us</a>
    </div>
    <div class="user-info">
        <?php
        if (isset($_SESSION['username'])) {
            echo "<a href='#'>Welcome, " . htmlspecialchars($_SESSION['username']) . "</a>";
            echo "<a href='logout.php'>Logout</a>";
        } else {
            echo "<a href='login.php'>Login</a>";
        }
        ?>
    </div>
</div>

<main>
    <h2 class="h">Your Wishlist</h2>

    <?php if (empty($wishlist)): ?>
        <p class="pp">Your wishlist is empty.</p>
    <?php else: ?>
        <table>
            <tr>
                <th>Image</th>
                <th>Product</th>
                <th>Price</th>
                <th>Action</th>
            </tr>
            <?php
            foreach ($wishlist as $product_id):
                $stmt = $conn->prepare("SELECT name, price, image FROM products WHERE id = ?");
                $stmt->bind_param("i", $product_id);
                $stmt->execute();
                $stmt->bind_result($name, $price, $image);
                if ($stmt->fetch()):
            ?>
            <tr>
                <td><img src="uploads/<?= $image ?>" alt="<?= htmlspecialchars($name) ?>"></td>
                <td><?= htmlspecialchars($name) ?></td>
                <td>₹<?= number_format($price, 2) ?></td>
                <td>
                    <form method="post" action="wishlist_action.php">
                        <input type="hidden" name="product_id" value="<?= $product_id ?>">
                        <input type="hidden" name="action" value="remove_wishlist">
                        <button type="submit" class="remove-btn">Remove</button>
                    </form>
                </td>
            </tr>
            <?php endif; endforeach; ?>
        </table>
    <?php endif; ?>
</main>

<footer class="footer">
  <div class="footer-container">
    <div class="footer-box">
      <h3>About Us</h3>
      <p>HotWheel Hub is your one-stop shop for authentic HotWheels collectible cars. Whether you're a hobbyist or a hardcore collector, we bring you rare and classic models at your fingertips.</p>
    </div>
    <div class="footer-box">
      <h3>Contact Us</h3>
      <p>Email: hotwheelhub95.com</p>
    </div>
    <div class="footer-box">
      <h3>Legal</h3>
      <ul>
        <li><a href="privacy.php">Privacy Policy</a></li>
        <li><a href="terms.php">Terms of Service</a></li>
      </ul>
    </div>
    <div class="footer-box">
      <h3>Follow Us</h3>
      <div class="footer-socials">
        <a href="#"><img src="images/instagram.png" alt="Instagram"></a>
        <a href="#"><img src="images/Facebook.png" alt="Facebook"></a>
        <a href="#"><img src="images/X.png" alt="Twitter"></a>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; 2025 HotWheel Store. All rights reserved.</p>
  </div>
</footer>

<!-- Scroll to Top Button -->
<button id="scrollTopBtn" onclick="scrollToTop()">&#8679;</button>
<script>
// Toggle menu (navbar)
function toggleMenu() {
    document.getElementById("menuLinks").classList.toggle("active");
}

// Scroll to Top
window.onscroll = function() {
    let btn = document.getElementById("scrollTopBtn");
    if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
        btn.style.display = "block";
    } else {
        btn.style.display = "none";
    }
};
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
</script>
</body>
</html>
