<?php
session_start();
include "db.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'];
    $product_id = intval($_POST['product_id']);

    if (!isset($_SESSION['wishlist'])) {
        $_SESSION['wishlist'] = [];
    }

    if ($action == 'add_wishlist') {
        // Add to wishlist
        if (!in_array($product_id, $_SESSION['wishlist'])) {
            $_SESSION['wishlist'][] = $product_id;
        }
        header("Location: wishlist.php");
        exit();
    } elseif ($action == 'remove_wishlist') {
        // Remove from wishlist
        $_SESSION['wishlist'] = array_filter($_SESSION['wishlist'], function($id) use ($product_id) {
            return $id != $product_id;
        });
        header("Location: wishlist.php");
        exit();
    }
}
?>
