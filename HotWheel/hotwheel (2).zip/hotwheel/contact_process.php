<?php
include 'db.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';


if (isset($_POST['name'], $_POST['email'], $_POST['message'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // ✅ Save to Database
    $sql = "INSERT INTO contact_messages (name, email, message) VALUES ('$name', '$email', '$message')";
    if (!mysqli_query($conn, $sql)) {
        die("Database insert failed: " . mysqli_error($conn));
    }

    // ✅ Send Email using PHPMailer
    $mail = new PHPMailer(true);

    try {
        // SMTP Debug
        $mail->SMTPDebug = 0; // Set 0 to disable
        $mail->Debugoutput = 'html';

        // SMTP Settings
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'hotwheelhub95@gmail.com';  // your Gmail
        $mail->Password   = 'yytx jigl njnm wpxl';      // your 16-digit App Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('hotwheelhub95@gmail.com', 'HotWheel Hub');
        $mail->addAddress('hotwheelhub95@gmail.com'); 
        $mail->addReplyTo($email, $name);

        // Content
        $mail->isHTML(true);
        $mail->Subject = "New Contact Message from " . $name;
        $mail->Body    = "
            <h2>New Contact Form Submission</h2>
            <p><b>Name:</b> $name</p>
            <p><b>Email:</b> $email</p>
            <p><b>Message:</b><br>$message</p>
        ";
        $mail->AltBody = "Name: $name\nEmail: $email\nMessage: $message";

        $mail->send();
        echo "success";

    } catch (Exception $e) {
        echo "Mailer Error: " . $mail->ErrorInfo;
    }
}
?>
