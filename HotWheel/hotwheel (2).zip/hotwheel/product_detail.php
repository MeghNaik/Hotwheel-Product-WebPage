<?php
session_start();
include "db.php";

if (!isset($_GET['id'])) {
    echo "Product not selected.";
    exit();
}

$product_id = intval($_GET['id']);
$product = $conn->query("SELECT p.*, c.name AS category_name 
                         FROM products p 
                         JOIN categories c ON p.category_id = c.id 
                         WHERE p.id = $product_id")->fetch_assoc();

if (!$product) {
    echo "Product not found.";
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($product['name']) ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f8f8f8;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
            margin: 0;
        }

        .product-card {
            display: flex;
            flex-direction: row;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            max-width: 1000px;
            width: 100%;
        }

        .product-image {
            width: 350px;
            flex-shrink: 0;
        }

        .product-image img {
            width: 100%;
            height: auto;
            display: block;
        }

        .product-details {
            flex: 1;
            padding: 30px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }

        .product-details h2 {
            margin-top: 0;
            font-size: 32px;
        }

        .product-details p {
            margin: 12px 0;
            font-size: 18px;
        }

        .price {
            font-size: 24px;
            color: red;
            font-weight: bold;
        }

        /* Buttons container */
        .btn-group {
            margin-top: 25px;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }

        /* General button style */
        .btn {
            flex: 1;
            min-width: 150px;
            padding: 14px 20px;
            border: none;
            border-radius: 6px;
            font-size: 18px;
            cursor: pointer;
            text-align: center;
            text-decoration: none;
            transition: transform 0.2s ease, opacity 0.2s ease;
            display: inline-block;
        }

        .btn:hover {
            transform: scale(1.05);
            opacity: 0.9;
        }

        /* Button colors */
        .btn-cart {
            background-color: #E95B5BFF;
            color: white;
        }

        .btn-wishlist {
            background-color: #ECE955FF;
            color: white;
        }

        .btn-back {
            background-color: #B3EB44FF;
            color: white;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .product-card {
                flex-direction: column;
                align-items: center;
            }

            .product-details {
                padding: 20px;
                text-align: center;
            }

            .btn-group {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="product-card">
    <div class="product-image">
        <img src="uploads/<?= htmlspecialchars($product['image']) ?>" alt="<?= htmlspecialchars($product['name']) ?>">
    </div>
    <div class="product-details">
        <h2><?= htmlspecialchars($product['name']) ?></h2>
        <p><strong>Category:</strong> <?= htmlspecialchars($product['category_name']) ?></p>
        <p class="price">₹<?= htmlspecialchars($product['price']) ?></p>
        <p><?= nl2br(htmlspecialchars($product['description'])) ?></p>

        <!-- Wrap all buttons inside one container -->
        <div class="btn-group">
            <form method="post" action="cart_action.php" style="flex:1;">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                <input type="hidden" name="action" value="add_cart">
                <button class="btn btn-cart" type="submit">Add to Cart</button>
            </form>

            <form method="post" action="wishlist_action.php" style="flex:1;">
                <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                <input type="hidden" name="action" value="add_wishlist">
                <button class="btn btn-wishlist" type="submit">Add to Wishlist</button>
            </form>

            <a href="index.php" class="btn btn-back"> Back</a>
        </div>
    </div>
</div>

</body>
</html>
