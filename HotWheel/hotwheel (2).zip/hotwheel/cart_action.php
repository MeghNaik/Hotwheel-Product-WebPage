<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action = $_POST['action'] ?? '';
    $product_id = intval($_POST['product_id'] ?? 0);

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if ($action === 'add_cart' && $product_id > 0) {
        if (isset($_SESSION['cart'][$product_id])) {
            // limit to max 10
            if ($_SESSION['cart'][$product_id] < 10) {
                $_SESSION['cart'][$product_id]++;
            }
        } else {
            $_SESSION['cart'][$product_id] = 1;
        }
    } elseif ($action === 'remove_cart') {
        unset($_SESSION['cart'][$product_id]);
    } elseif ($action === 'increase_quantity') {
        if (isset($_SESSION['cart'][$product_id]) && $_SESSION['cart'][$product_id] < 10) {
            $_SESSION['cart'][$product_id]++;
        }
    } elseif ($action === 'decrease_quantity') {
        if (isset($_SESSION['cart'][$product_id]) && $_SESSION['cart'][$product_id] > 1) {
            $_SESSION['cart'][$product_id]--;
        }
    }

    header("Location: cart.php");
    exit();
}
