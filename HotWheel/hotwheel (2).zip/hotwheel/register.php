<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f6f8;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .form-container {
      background-color: #ffffff;
      padding: 40px 30px;
      border-radius: 12px;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 400px;
      text-align: center;
    }

    .form-container h2 {
      margin-bottom: 25px;
      color: black;
    }

    .input-group {
      position: relative;
      margin-bottom: 15px;
      text-align: left;
    }

    .input-group input {
      width: 100%;
      padding: 12px;
      border: 1px solid #ccc;
      border-radius: 8px;
      box-sizing: border-box;
      font-size: 16px;
    }

    .input-group small {
      color: red;
      font-size: 13px;
      display: none;
    }

    .toggle-password {
      position: absolute;
      right: 12px;
      top: 50%;
      transform: translateY(-50%);
      cursor: pointer;
      font-size: 16px;
      color: #888;
    }

    form button {
      width: 100%;
      padding: 12px;
      background-color: #E95B5BFF;
      border: none;
      color: white;
      font-size: 16px;
      border-radius: 8px;
      cursor: pointer;
    }

    form button:hover {
      background-color: #ECE955FF;
    }

    input:valid {
      border-color: green;
    }
  </style>
</head>
<body>

<div class="form-container">
  <h2>User Registration</h2>
  <form id="registerForm" novalidate>
    
    <div class="input-group">
      <input type="text" id="username" name="username" placeholder="Username" required minlength="3">
      <small>Username must be at least 3 characters</small>
    </div>

    <div class="input-group">
      <input type="email" id="email" name="email" placeholder="Email" required>
      <small>Enter a valid email</small>
    </div>

    <div class="input-group">
      <input type="password" id="password" name="password" placeholder="Password" required minlength="6">
      <span class="toggle-password" onclick="togglePassword('password', this)">👁</span>
      <small>Password must be at least 6 characters</small>
    </div>

    <div class="input-group">
      <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirm Password" required>
      <span class="toggle-password" onclick="togglePassword('confirm_password', this)">👁</span>
      <small>Passwords do not match</small>
    </div>

    <!-- CAPTCHA -->
    <div class="input-group">
      <label for="captcha">Solve: <span id="captchaQuestion"></span></label>
      <input type="text" id="captcha" name="captcha" placeholder="Enter answer" required>
      <small>Wrong answer</small>
    </div>

    <button type="submit">Register</button>
  </form>
</div>

<script>
  const form = document.getElementById('registerForm');
  const username = document.getElementById('username');
  const email = document.getElementById('email');
  const password = document.getElementById('password');
  const confirmPassword = document.getElementById('confirm_password');
  const captchaInput = document.getElementById('captcha');

  // Generate math captcha
  let num1 = Math.floor(Math.random() * 10) + 1;
  let num2 = Math.floor(Math.random() * 10) + 1;
  document.getElementById("captchaQuestion").innerText = `${num1} + ${num2} = ?`;
  const correctCaptcha = num1 + num2;

  // Add hidden field for captcha correct answer
  let hiddenInput = document.createElement("input");
  hiddenInput.type = "hidden";
  hiddenInput.name = "captcha_correct";
  hiddenInput.value = correctCaptcha;
  form.appendChild(hiddenInput);

  function showError(input, message) {
    const small = input.parentElement.querySelector('small');
    small.innerText = message;
    small.style.display = 'block';
    input.style.borderColor = 'red';
  }

  function showSuccess(input) {
    const small = input.parentElement.querySelector('small');
    small.style.display = 'none';
    input.style.borderColor = 'green';
  }

  function validateEmail(emailVal) {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(emailVal);
  }

  // live validation
  form.addEventListener('input', () => {
    if (username.value.length >= 3) showSuccess(username);
    else showError(username, 'Username must be at least 3 characters');

    if (validateEmail(email.value)) showSuccess(email);
    else showError(email, 'Enter a valid email');

    if (password.value.length >= 6) showSuccess(password);
    else showError(password, 'Password must be at least 6 characters');

    if (confirmPassword.value === password.value && confirmPassword.value !== "") {
      showSuccess(confirmPassword);
    } else {
      showError(confirmPassword, 'Passwords do not match');
    }

    if (parseInt(captchaInput.value) === correctCaptcha) {
      showSuccess(captchaInput);
    } else {
      showError(captchaInput, 'Wrong answer');
    }
  });

  // submit with AJAX
  form.addEventListener('submit', (e) => {
    e.preventDefault();

    if (
      username.value.length >= 3 &&
      validateEmail(email.value) &&
      password.value.length >= 6 &&
      confirmPassword.value === password.value &&
      parseInt(captchaInput.value) === correctCaptcha
    ) {
      const formData = new FormData(form);

      fetch("register_action.php", {
        method: "POST",
        body: formData
      })
      .then(res => res.text())
      .then(data => {
        if (data.trim() === "success") {
          alert("Registration successful ✅ Redirecting to login...");
          window.location.href = "login.php";
        } else {
          alert("⚠️ " + data);
        }
      })
      .catch(err => {
        alert("Error: " + err);
      });

    } else {
      alert("❌ Please correct errors before submitting.");
    }
  });

  // toggle password visibility
  function togglePassword(fieldId, icon) {
    const field = document.getElementById(fieldId);
    if (field.type === "password") {
      field.type = "text";
      icon.textContent = "👁";
    } else {
      field.type = "password";
      icon.textContent = "👁";
    }
  }
</script>

</body>
</html>
