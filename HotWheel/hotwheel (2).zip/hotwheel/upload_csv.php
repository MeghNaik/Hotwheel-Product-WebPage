<?php
session_start();
include "db.php";

if (isset($_POST['import'])) {
    $file = $_FILES['csv_file']['tmp_name'];

    if ($_FILES['csv_file']['size'] > 0) {
        $handle = fopen($file, "r");

        // Skip header row
        fgetcsv($handle);

        while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
            $name = trim($data[0]);          // same for category + product
            $description = trim($data[1]);
            $price = floatval($data[2]);
            $image = trim($data[3]);

            if ($name == "") continue; // Skip empty rows

            //Check if category already exists
            $cat_id = 0;
            $res = $conn->prepare("SELECT id FROM categories WHERE name=? LIMIT 1");
            $res->bind_param("s", $name);
            $res->execute();
            $res->bind_result($cat_id);
            $res->fetch();
            $res->close();

            // If category not found, insert new
            if ($cat_id == 0) {
                $stmt = $conn->prepare("INSERT INTO categories (name) VALUES (?)");
                $stmt->bind_param("s", $name);
                $stmt->execute();
                $cat_id = $conn->insert_id;
                $stmt->close();
            }

            //Check if product already exists for this category
            $product_exists = 0;
            $check = $conn->prepare("SELECT id FROM products WHERE category_id=? AND name=? LIMIT 1");
            $check->bind_param("is", $cat_id, $name);
            $check->execute();
            $check->bind_result($product_exists);
            $check->fetch();
            $check->close();

            // If product not exists, insert new
            if ($product_exists == 0) {
                $stmt2 = $conn->prepare("INSERT INTO products (category_id, name, description, price, image) 
                                         VALUES (?, ?, ?, ?, ?)");
                $stmt2->bind_param("issds", $cat_id, $name, $description, $price, $image);
                $stmt2->execute();
                $stmt2->close();
            }
        }

        fclose($handle);
        echo "<p style='color:green;'>✅ CSV Import Successful! Only new records added.</p>";
    } else {
        echo "<p style='color:red;'>⚠️ Please upload a valid CSV file.</p>";
    }
}
?>

<!-- ✅ Upload Form -->
<form method="post" enctype="multipart/form-data">
    <input type="file" name="csv_file" required>
    <button type="submit" name="import">Import CSV</button>
</form>
