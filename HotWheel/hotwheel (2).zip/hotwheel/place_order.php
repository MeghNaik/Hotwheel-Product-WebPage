<?php
session_start();
include "db.php";
require 'vendor/autoload.php'; // for Stripe

\Stripe\Stripe::setApiKey("sk_test_51S7WaBBgbQgglgvsU8VyjXCLQp58uSr8mgCtF0s6B3AQxfBAG4WDE7d1zJX3QQpOrloLarkLmn24SfF9xHSrLbnS00ZZ0F01ob"); // your secret key

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

// Default
$payment_method = "Stripe";
$payment_detail = "";
// 1. Check for COD via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['payment_method']) && $_POST['payment_method'] === 'COD') {
    $status = "success";
    $payment_method = "COD";
    $payment_detail = "Cash on Delivery";

// 2. Check for Stripe via GET session_id
} elseif (isset($_GET['session_id'])) {
    $session_id = $_GET['session_id'];
    try {
        $checkout_session = \Stripe\Checkout\Session::retrieve($session_id);
        if ($checkout_session->payment_status === "paid") {
            $status = "success";
            $payment_method = "Stripe";
            $payment_detail = "Paid via Stripe (Session: $session_id)";
        } else {
            echo "<h2 style='color:red;'>Payment Failed ❌</h2>";
            exit();
        }
    } catch (Exception $e) {
        echo "<h2>Error verifying payment ⚠️</h2>";
        exit();
    }

// 3. Cancelled
} elseif (isset($_GET['status']) && $_GET['status'] === 'cancel') {
    echo "<h2 style='color:red;'>Payment Cancelled ❌</h2>";
    exit();

// 4. Otherwise unknown
} else {
    echo "<h2>Unknown Payment Status ⚠️</h2>";
    exit();
}


// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_id = (int) $_SESSION['user_id'];

// Collect shipping & payment info
$shipping_address = trim($_POST['shipping_address'] ?? '');
$payment_method   = $_POST['payment_method'] ?? 'Stripe';
$payment_detail   = $payment_method === "COD" ? "Cash on Delivery" : "Paid via Stripe";

// Build cart data
$cart_data = [];
$order_total = 0.0;

if (!empty($_SESSION['cart']) && is_array($_SESSION['cart'])) {
    foreach ($_SESSION['cart'] as $pid => $qty) {
        $pid = (int)$pid;
        $qty = (int)$qty;
        if ($qty <= 0) continue;

        $stmt_p = $conn->prepare("SELECT name, price FROM products WHERE id = ?");
        $stmt_p->bind_param("i", $pid);
        $stmt_p->execute();
        $res = $stmt_p->get_result();
        $prod = $res->fetch_assoc();
        $stmt_p->close();

        if (!$prod) continue;
        $price = (float)$prod['price'];
        $name  = $prod['name'];
        $item_total = $price * $qty;
        $order_total += $item_total;

        $cart_data[] = [
            'product_id' => $pid,
            'qty' => $qty,
            'price' => $price,
            'total' => $item_total,
            'name' => $name
        ];
    }
}

// If still empty, try DB cart
if (empty($cart_data)) {
    $stmt = $conn->prepare("SELECT product_id, quantity FROM cart_items WHERE user_id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $pid = (int)$row['product_id'];
        $qty = (int)$row['quantity'];
        if ($qty <= 0) continue;

        $stmt_p = $conn->prepare("SELECT name, price FROM products WHERE id = ?");
        $stmt_p->bind_param("i", $pid);
        $stmt_p->execute();
        $r2 = $stmt_p->get_result();
        $prod = $r2->fetch_assoc();
        $stmt_p->close();

        if (!$prod) continue;
        $price = (float)$prod['price'];
        $name  = $prod['name'];
        $item_total = $price * $qty;
        $order_total += $item_total;

        $cart_data[] = [
            'product_id' => $pid,
            'qty' => $qty,
            'price' => $price,
            'total' => $item_total,
            'name' => $name
        ];
    }
    $stmt->close();
}

// If no items, stop
if (empty($cart_data)) {
    echo "<p>Your cart is empty. <a href='index.php'>Go Shopping</a></p>";
    exit();
}

// Insert into orders table
$insertOrder = $conn->prepare("INSERT INTO orders (user_id, total_price, shipping_address, payment_method, payment_detail) VALUES (?, ?, ?, ?, ?)");
$insertOrder->bind_param("idsss", $user_id, $order_total, $shipping_address, $payment_method, $payment_detail);
$insertOrder->execute();
$order_id = $insertOrder->insert_id;
$insertOrder->close();

// Insert order items
$insertItem = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
foreach ($cart_data as $item) {
    $pid = (int)$item['product_id'];
    $qty = (int)$item['qty'];
    $price = (float)$item['price'];

    $insertItem->bind_param("iiid", $order_id, $pid, $qty, $price);
    $insertItem->execute();
}
$insertItem->close();

// Clear cart
unset($_SESSION['cart']);
$conn->query("DELETE FROM cart_items WHERE user_id = " . intval($user_id));

// Fetch user info
$stmt_user = $conn->prepare("SELECT email, username FROM users WHERE id = ?");
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$stmt_user->bind_result($user_email, $username);
$stmt_user->fetch();
$stmt_user->close();

// Prepare email
$order_items_list = "";
foreach ($cart_data as $it) {
    $order_items_list .= "<li>" . htmlspecialchars($it['name']) . " (Qty: " . intval($it['qty']) . ") - ₹" . number_format($it['total'],2) . "</li>";
}
$subject = "Order Confirmation - HotWheel Hub (Order #{$order_id})";
$body = "
    <h2>Order Details</h2>
    <p><strong>Order ID:</strong> {$order_id}</p>
    <p><strong>Customer:</strong> " . htmlspecialchars($username) . " (" . htmlspecialchars($user_email) . ")</p>
    <p><strong>Payment Method:</strong> " . htmlspecialchars($payment_method) . "</p>
    <p><strong>Shipping Address:</strong> " . nl2br(htmlspecialchars($shipping_address)) . "</p>
    <p><strong>Total:</strong> ₹" . number_format($order_total,2) . "</p>
    <h3>Items:</h3>
    <ul>{$order_items_list}</ul>
";

// Send email to customer
try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = "smtp.gmail.com";
    $mail->SMTPAuth   = true;
    $mail->Username   = "hotwheelhub95@gmail.com";
    $mail->Password   = "yytx jigl njnm wpxl"; // Gmail app password
    $mail->SMTPSecure = "tls";
    $mail->Port       = 587;

    $mail->setFrom("hotwheelhub95@gmail.com", "HotWheel Hub");
    $mail->addAddress($user_email, $username);

    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body    = "<h2>Thank you for your order, " . htmlspecialchars($username) . "!</h2>" . $body;
    $mail->send();
} catch (Exception $e) { }

// Send admin copy
try {
    $mail_admin = new PHPMailer(true);
    $mail_admin->isSMTP();
    $mail_admin->Host       = "smtp.gmail.com";
    $mail_admin->SMTPAuth   = true;
    $mail_admin->Username   = "hotwheelhub95@gmail.com";
    $mail_admin->Password   = "yytx jigl njnm wpxl"; 
    $mail_admin->SMTPSecure = "tls";
    $mail_admin->Port       = 587;

    $mail_admin->setFrom("hotwheelhub95@gmail.com", "HotWheel Hub");
    $mail_admin->addAddress("hotwheelhub95@gmail.com", "Store Owner");

    $mail_admin->isHTML(true);
    $mail_admin->Subject = "New Order Received - Order #{$order_id}";
    $mail_admin->Body    = "<h2>New Order Alert</h2>" . $body;
    $mail_admin->send();
} catch (Exception $e) { }

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Order Confirmation</title>
<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: #f7f9fc;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 700px;
        margin: 50px auto;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        padding: 30px;
    }
    h1 {
        text-align: center;
        color: #E95B5BFF;
    }
    .order-info {
        margin: 20px 0;
        padding: 15px;
        background: #f0f4ff;
        border-left: 5px solid #E95B5BFF;
        border-radius: 8px;
    }
    .order-info p {
        margin: 8px 0;
        font-size: 16px;
    }
    .items {
        margin: 20px 0;
    }
    .items h3 {
        margin-bottom: 10px;
        color: #333;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        background: #fff;
    }
    th, td {
        border: 1px solid #ddd;
        padding: 12px;
        text-align: left;
        font-size: 15px;
    }
    th {
        background: #E95B5BFF;
        color: white;
    }
    .total {
        text-align: right;
        font-weight: bold;
        font-size: 18px;
        margin-top: 20px;
        color: #E95B5BFF;
    }
    .btn {
        display: block;
        width: 200px;
        margin: 30px auto 0;
        text-align: center;
        padding: 12px;
        background: #E95B5BFF;
        color: #fff;
        text-decoration: none;
        border-radius: 6px;
    }
    .btn:hover {
        background: #ECE955FF;
    }
</style>
</head>
<body>
<div class="container">
    <h1>Order Confirmed!</h1>
    <div class="order-info">
        <p><strong>Order ID:</strong> <?php echo $order_id; ?></p>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($username); ?></p>
        <p><strong>Email:</strong> <?php echo htmlspecialchars($user_email); ?></p>
        <p><strong>Payment Method:</strong> <?php echo htmlspecialchars($payment_method); ?></p>
        <p><strong>Shipping Address:</strong><br><?php echo nl2br(htmlspecialchars($shipping_address)); ?></p>
    </div>

    <div class="items">
        <h3>Your Items</h3>
        <table>
            <tr>
                <th>Product</th>
                <th>Qty</th>
                <th>Price</th>
                <th>Total</th>
            </tr>
            <?php foreach ($cart_data as $it): ?>
            <tr>
                <td><?php echo htmlspecialchars($it['name']); ?></td>
                <td><?php echo intval($it['qty']); ?></td>
                <td>₹<?php echo number_format($it['price'], 2); ?></td>
                <td>₹<?php echo number_format($it['total'], 2); ?></td>
            </tr>
            <?php endforeach; ?>
        </table>
        <p class="total">Grand Total: ₹<?php echo number_format($order_total, 2); ?></p>
    </div>

    <a href="index.php" class="btn">Continue Shopping</a>
</div>
</body>
</html>

