<?php
session_start();
include "../db.php";

// Redirect if not admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin_login.php");
    exit();
}

// Handle Add User
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {
    $username = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password_hash = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'] ?? 'user';
    $added_by = $_SESSION['user_id']; // logged in admin id

    $stmt = $conn->prepare("INSERT INTO users (username, email, password_hash, role, created_at, added_by) VALUES (?, ?, ?, ?, NOW(), ?)");
    $stmt->bind_param("ssssi", $username, $email, $password_hash, $role, $added_by);
    $stmt->execute();
    $stmt->close();

    header("Location: users.php?msg=added");
    exit();
}

// Handle Delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM users WHERE id=$id");
    header("Location: users.php?msg=deleted");
    exit();
}

// Get Users with Added By info
$result = $conn->query("SELECT 
                            u.id AS user_id, 
                            u.username, 
                            u.email, 
                            u.role, 
                            u.created_at, 
                            a.username AS added_by 
                        FROM users u 
                        LEFT JOIN users a ON u.added_by = a.id");
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Users</title>
    <style>
        body {
            background: #f8f9fa;
            font-family: Arial, sans-serif;
            padding: 20px;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            justify-content: center;
        }

        .form-container, table {
            background: #fff;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            margin-bottom: 20px;
        }

        .form-container {
            flex: 1 1 350px;
            max-width: 420px;
        }

        .form-container h2, h2 {
            margin-bottom: 20px;
            font-size: 20px;
            font-weight: bold;
            color: black;
            text-align: center;
        }

        .form-container label {
            display: block;
            text-align: left;
            margin-bottom: 6px;
            font-weight: 500;
            color: black;
        }

        .form-container input,
        .form-container select {
            width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 16px;
        }

        .form-container button {
            width: 100%;
            padding: 12px;
            background: #E95B5B;
            color: white;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            margin-bottom: 12px;
        }

        .form-container button:hover {
            background: #F2D666;
        }

        .back-btn {
            display: inline-block;
            padding: 10px 20px;
            background: #E95B5B;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
        }

        .back-btn:hover {
            background: #F2D666;
        }

        table {
            flex: 2 1 600px;
            border-collapse: collapse;
            width: 100%;
        }

        table th, table td {
            border: 1px solid #ccc;
            padding: 12px 5px;
            text-align: center;
        }

        table th {
            background: #d4ac0d;
            color: white;
        }

        .action-btn {
            padding: 6px 12px;
            margin: 2px;
            border-radius: 6px;
            text-decoration: none;
            color: white;
            font-size: 14px;
        }

        .edit-btn { background: #f39c12; }
        .delete-btn { background: #E95B5B; }

        /* Responsive */
        @media(max-width: 768px) {
            .container { flex-direction: column; }
            table { font-size: 14px; }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Add User Form -->
        <div class="form-container">
            <h2>Add New User</h2>
            <form method="POST">
                <label>Name:</label>
                <input type="text" name="name" required>

                <label>Email:</label>
                <input type="email" name="email" required>

                <label>Password:</label>
                <input type="password" name="password" required>

                <label>Role:</label>
                <select name="role">
                    <option value="user">User</option>
                    <option value="admin">Admin</option>
                </select>

                <button type="submit" name="add_user">Add User</button>
            </form>
            <a href="admin_dashboard.php" class="back-btn">Back</a>
        </div>

        <!-- User List -->
        <div style="overflow-x:auto;">
            <h2>User List</h2>
            <table>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Added By</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
                <?php while($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row['user_id']; ?></td>
                        <td><?= htmlspecialchars($row['username']); ?></td>
                        <td><?= htmlspecialchars($row['email']); ?></td>
                        <td><?= ucfirst($row['role']); ?></td>
                        <td><?= $row['added_by'] ?? 'System'; ?></td>
                        <td><?= $row['created_at']; ?></td>
                        <td>
                            <a href="edit_user.php?id=<?= $row['user_id']; ?>" class="action-btn edit-btn">Edit</a>
                            <a href="users.php?delete=<?= $row['user_id']; ?>" class="action-btn delete-btn" onclick="return confirm('Are you sure?');">Delete</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </div>
</body>
</html>
