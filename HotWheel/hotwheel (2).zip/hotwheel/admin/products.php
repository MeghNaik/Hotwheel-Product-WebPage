<?php
session_start();
include "../db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin_login.php");
    exit();
}

$result = $conn->query("SELECT products.*, categories.name AS category FROM products JOIN categories ON products.category_id = categories.id");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Products</title>
    <style>
        /* Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* Container */
.form-container {
    background: #fff;
    padding: 30px 40px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25);
    width: 950px;
    text-align: center;
}

/* Heading */
.form-container h2 {
    margin-bottom: 20px;
    font-size: 26px;
    color: black;
}

/* Button Group */
.button-group {
    display: flex;
    justify-content: space-between;
    margin-bottom: 20px;
}

/* Back Button */
.back-btn {
    background: #E95B5BFF;
    color: white;
    padding: 12px 20px;
    border-radius: 10px;
    text-decoration: none;
    font-weight: bold;
}

.back-btn:hover {
    background: #F2D666FF;
}

/* Add Button */
.add-btn {
    background: #E95B5BFF;
    color: white;
    padding: 12px 20px;
    border-radius: 10px;
    text-decoration: none;
    font-weight: bold;
}

.add-btn:hover {
    background: #F2D666FF;
}

/* Table */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
}

table th, table td {
    padding: 14px;
    text-align: center;
    font-size: 15px;
}

table th {
    background: #d4ac0d;
    color: white;
    font-size: 16px;
}

table tr:nth-child(even) {
    background: #f9f9f9;
}

table tr:hover {
    background: #f1f1f1;
    transition: 0.2s ease-in-out;
}

/* Action Buttons */
.edit-btn, .delete-btn {
    text-decoration: none;
    padding: 8px 14px;
    border-radius: 6px;
    font-weight: bold;
    transition: 0.3s ease;
    display: inline-block;
}

.edit-btn {
    background: #f39c12;
    color: white;
    margin-right: 6px;
}

.edit-btn:hover {
    background: #e67e22;
}

.delete-btn {
    background: #e74c3c;
    color: white;
}

.delete-btn:hover {
    background: #c0392b;
}

/* Fade-in Animation */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(-20px); }
    to { opacity: 1; transform: translateY(0); }
}

    </style>
</head>
<body>
<div class="form-container">
    <h2>Products</h2>

    <!-- Back & Add Buttons -->
    <div class="button-group">
        <a href="admin_dashboard.php" class="back-btn">Back</a>
        <a href="add_product.php" class="add-btn">Add New Product</a>
    </div>

    <table>
        <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>
        <?php while($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['id'] ?></td>
            <td><?= htmlspecialchars($row['name']) ?></td>
            <td><?= $row['category'] ?></td>
            <td>₹<?= number_format($row['price'], 2) ?></td>
            <td><img src="../uploads/<?= $row['image'] ?>" width="60" style="border-radius:6px;"></td>
            <td>
                <a href="edit_product.php?id=<?= $row['id'] ?>" class="edit-btn">Edit</a>
                <a href="delete_product.php?id=<?= $row['id'] ?>" class="delete-btn" onclick="return confirm('Delete this product?')">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>
