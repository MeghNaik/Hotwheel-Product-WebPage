<?php
session_start();
include "../db.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $conn->query("DELETE FROM categories WHERE id = $id");
}

header("Location: categories.php");
exit();
