<?php
session_start();
if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin') {
    header("Location: admin_dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>
    <style>
        /* Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        .form-container {
            background: #ffffff;
            padding: 30px 40px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            width: 350px;
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
        }

        input {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.3s;
        }

        input.error {
            border-color: red;
        }

        .error-message {
            font-size: 12px;
            color: red;
            text-align: left;
            margin-top: -8px;
            margin-bottom: 10px;
            display: none;
        }

        button {
            width: 100%;
            padding: 12px;
            background: #E95B5B;
            border: none;
            color: #fff;
            font-size: 16px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
        }

        button:hover {
            background: #F2D666;
        }
    </style>
</head>
<body>
<div class="form-container">
    <h2>Admin Login</h2>
    <form method="POST" action="admin_login_action.php" id="loginForm">
        <input type="email" name="email" id="email" placeholder="Admin Email" required>
        <div id="emailError" class="error-message">Please enter a valid email.</div>

        <input type="password" name="password" id="password" placeholder="Password" required>
        <div id="passwordError" class="error-message">Password must be at least 6 characters.</div>

        <button type="submit">Login</button>
    </form>
</div>

<script>
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const emailError = document.getElementById("emailError");
    const passwordError = document.getElementById("passwordError");
    const form = document.getElementById("loginForm");

    // Email Validation
    email.addEventListener("input", () => {
        const emailPattern = /^[^ ]+@[^ ]+\.[a-z]{2,3}$/;
        if (!email.value.match(emailPattern)) {
            email.classList.add("error");
            emailError.style.display = "block";
        } else {
            email.classList.remove("error");
            emailError.style.display = "none";
        }
    });

    // Password Validation
    password.addEventListener("input", () => {
        if (password.value.length < 6) {
            password.classList.add("error");
            passwordError.style.display = "block";
        } else {
            password.classList.remove("error");
            passwordError.style.display = "none";
        }
    });

    // Prevent form submission if invalid
    form.addEventListener("submit", (e) => {
        if (email.classList.contains("error") || password.classList.contains("error")) {
            e.preventDefault();
        }
    });
</script>
</body>
</html>
