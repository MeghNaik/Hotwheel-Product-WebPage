<?php
session_start();
include "../db.php";

if (!isset($_GET['id'])) {
    header("Location: categories.php");
    exit();
}

$id = $_GET['id'];
$category = $conn->query("SELECT * FROM categories WHERE id = $id")->fetch_assoc();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $stmt = $conn->prepare("UPDATE categories SET name = ? WHERE id = ?");
    $stmt->bind_param("si", $name, $id);
    $stmt->execute();
    header("Location: categories.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Edit Category</title>
    <style>
        /* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

/* Body */
body {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* Container */
.form-container {
    background: #fff;
    padding: 30px 40px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25);
    width: 400px;
    text-align: center;
}

/* Heading */
.form-container h2 {
    margin-bottom: 20px;
    font-size: 26px;
    color: black;
}

/* Input Field */
.form-container input[type="text"] {
    width: 100%;
    padding: 12px 14px;
    margin-bottom: 20px;
    border: 2px solid #ccc;
    border-radius: 10px;
    font-size: 16px;
    transition: 0.3s ease;
}


/* Submit Button */
.form-container button {
    background: #E95B5BFF;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
    width: 100%;
}

.form-container button:hover {
    background: #F2D666FF ;
}

/* Fade-in Animation */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

    </style>    
</head>
<body>
<div class="form-container">
    <h2>Edit Category</h2>
    <form method="POST">
        <input type="text" name="name" value="<?= htmlspecialchars($category['name']) ?>" required><br>
        <button type="submit">Update</button>
    </form>
</div>
</body>
</html>
