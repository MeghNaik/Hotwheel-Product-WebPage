<?php
session_start();
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin_login.php");
    exit();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>
    <style>
        /* General reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

/* Body styling */
body {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* Dashboard container */
.form-container {
    background: #fff;
    padding: 40px 50px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25);
    text-align: center;
    width: 400px;
}

/* Heading */
.form-container h2 {
    margin-bottom: 30px;
    font-size: 26px;
    color: black;
}
.form-container a {
    text-decoration: none;   
    color: white;         
    display: block;
}
/* Buttons */
.form-container a button {
    display: block;
    width: 100%;
    margin: 12px 0;
    padding: 14px;
    font-size: 18px;
    border: none;
    border-radius: 12px;
    cursor: pointer;
    background: linear-gradient(135deg, #E95B5BFF, #F2D666FF);
    color: white;
}

/* Hover Effects */
.form-container a button:hover {
    box-shadow: 0 6px 15px rgba(0, 0, 0, 0.35);
}

/* Animation */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

    </style>
</head>
<body>
<div class="form-container">
    <h2>Welcome,  <?= $_SESSION['username'] ?></h2>
    <a href="categories.php"><button>Manage Categories</button></a>
    <a href="products.php"><button>Manage Products</button></a>
    <a href="users.php"><button>Manage Users</button></a>
    <a href="admin_orders.php"><button>Orders</button></a>
    <a href="admin_logout.php"><button>Logout</button></a>
</div>
</body>
</html>
