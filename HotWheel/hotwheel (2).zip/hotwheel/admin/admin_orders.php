<?php
session_start();
include("../db.php");

// ✅ Ensure admin access
if (!isset($_SESSION['role']) || $_SESSION['role'] != 'admin') {
    die("Access denied. <a href='login.php'>Login as admin</a>");
}

// ✅ Handle status update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['order_id'], $_POST['status'])) {
    $order_id = intval($_POST['order_id']);
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->bind_param("si", $status, $order_id);
    $stmt->execute();
}

// ✅ Fetch all orders
$result = $conn->query("
    SELECT o.*, u.username 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    ORDER BY o.created_at DESC
");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Orders</title>
    <style>
        /* Reset */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
    font-family: Arial, sans-serif;
        }

        body {
            background: #f8f9fa;
            padding: 40px;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: black;
        }

        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            overflow: hidden;
        }

        th {
            background: #CBAC24FF;
            color: #fff;
            padding: 14px;
            text-align: left;
            font-size: 15px;
        }

        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
            font-size: 14px;
            color: black;
            vertical-align: top;
        }


        ul {
            margin-left: 18px;
            padding-left: 0;
        }

        select {
            padding: 6px 10px;
            border-radius: 6px;
            border: 1px solid #ccc;
            font-size: 14px;
            cursor: pointer;
        }

        select:focus {
            border-color: #E95B5B;
        }

        form {
            display: inline;
        }

        /* Back button */
        .back-btn {
            display: inline-block;
            margin-top: 20px;
            padding: 10px 20px;
            background: #E95B5B;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
        }

        .back-btn:hover {
            background: #F2D666;
        }
    </style>
</head>
<body>

    <h2>All Orders</h2>

    <table>
        <tr>
            <th>ID</th>
            <th>User</th>
            <th>Total</th>
            <th>Shipping Address</th>
            <th>Payment</th>
            <th>Status</th>
            <th>Items</th>
            <th>Action</th>
        </tr>

        <?php while ($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['username']) ?></td>
                <td>₹<?= number_format($row['total_price'], 2) ?></td>
                <td><?= nl2br(htmlspecialchars($row['shipping_address'])) ?></td>
                <td><?= $row['payment_method'] ?></td>
                <td><strong><?= $row['status'] ?></strong></td>
                <td>
                    <ul>
                    <?php
                    if ($stmtItems = $conn->prepare("
                        SELECT p.name 
                        FROM order_items oi 
                        JOIN products p ON oi.product_id = p.id 
                        WHERE oi.order_id = ?
                    ")) {
                        $stmtItems->bind_param("i", $row['id']);
                        $stmtItems->execute();
                        $itemsResult = $stmtItems->get_result();

                        while ($item = $itemsResult->fetch_assoc()) {
                            echo "<li>" . htmlspecialchars($item['name']) . "</li>";
                        }
                        $stmtItems->close();
                    } else {
                        echo "<li>Error loading items</li>";
                    }
                    ?>
                    </ul>
                </td>
                <td>
                    <form method="POST">
                        <input type="hidden" name="order_id" value="<?= $row['id'] ?>">
                        <select name="status" onchange="this.form.submit()">
                            <?php
                            $statuses = ['Pending', 'Shipped', 'Delivered', 'Cancelled'];
                            foreach ($statuses as $s) {
                                $selected = ($row['status'] === $s) ? 'selected' : '';
                                echo "<option value='$s' $selected>$s</option>";
                            }
                            ?>
                        </select>
                    </form>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>

    <div style="text-align:center;">
        <a href="admin_dashboard.php" class="back-btn">Back</a>
    </div>

</body>
</html>
