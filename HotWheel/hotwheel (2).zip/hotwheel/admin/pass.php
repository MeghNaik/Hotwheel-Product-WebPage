<?php
// Change this to your desired admin password
$plainPassword = "admin123";

// Hash the password using bcrypt
$hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);

// Display the result
echo "Plain Password: " . $plainPassword . "<br>";
echo "Hashed Password: <br><textarea rows='2' cols='80'>" . $hashedPassword . "</textarea>";
?>
    