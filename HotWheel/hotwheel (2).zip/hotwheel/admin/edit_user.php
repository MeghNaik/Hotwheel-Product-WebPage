<?php
session_start();
include "../db.php";

// Redirect if not admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin_login.php");
    exit();
}

// Get user id
if (!isset($_GET['id'])) {
    header("Location: users.php");
    exit();
}
$id = intval($_GET['id']);

// Fetch user
$stmt = $conn->prepare("SELECT username, email, role FROM users WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($username, $email, $role);
$stmt->fetch();
$stmt->close();

// Update user
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_username = trim($_POST['username']);
    $new_email = trim($_POST['email']);
    $new_role = $_POST['role'];
    
    if (!empty($_POST['password'])) {
        $new_password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt = $conn->prepare("UPDATE users SET username=?, email=?, password_hash=?, role=? WHERE id=?");
        $stmt->bind_param("ssssi", $new_username, $new_email, $new_password, $new_role, $id);
    } else {
        $stmt = $conn->prepare("UPDATE users SET username=?, email=?, role=? WHERE id=?");
        $stmt->bind_param("sssi", $new_username, $new_email, $new_role, $id);
    }
    $stmt->execute();
    $stmt->close();

    header("Location: users.php?msg=updated");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit User</title>
    <style>
        body {
            background: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            font-family: Arial, sans-serif;
        }

        .form-container {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            width: 400px;
        }

        h2 { text-align: center; margin-bottom: 20px; }

        label { display: block; margin-bottom: 6px; }

        input, select {
             width: 100%;
    padding: 12px;
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 16px;
}
        

        button {
            width: 55%;
            padding: 12px;
            background: #E95B5B;
            color: white;
            border: none;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
        }

        button:hover { background: #F2D666; }

        .back-btn {
            display: inline-block;
            margin-top: 10px;
            text-align: center;
            padding: 10px;
            background: #E95B5B;
            color: white;
            border-radius: 8px;
            text-decoration: none;
            width: 50%;
            display: block;
        }
        .back-btn:hover { background: #F2D666; }
    </style>
</head>
<body>
    <div class="form-container">
        <h2>Edit User</h2>
        <form method="POST">
            <label>Username:</label>
            <input type="text" name="username" value="<?= htmlspecialchars($username); ?>" required>

            <label>Email:</label>
            <input type="email" name="email" value="<?= htmlspecialchars($email); ?>" required>

            <label>Password (leave blank to keep current):</label>
            <input type="password" name="password">

            <label>Role:</label>
            <select name="role">
                <option value="user" <?= $role === 'user' ? 'selected' : ''; ?>>User</option>
                <option value="admin" <?= $role === 'admin' ? 'selected' : ''; ?>>Admin</option>
            </select>

            <button type="submit">Update User</button>
        </form>
        <a href="users.php" class="back-btn">Back</a>
    </div>
</body>
</html>
