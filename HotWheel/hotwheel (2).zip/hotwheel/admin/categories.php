<?php
session_start();
include "../db.php";

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: admin_login.php");
    exit();
}

$result = $conn->query("SELECT * FROM categories");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Categories</title>
    <style>
        /* General Reset */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

/* Body */
body {
    min-height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
}

/* Container */
.form-container {
    background: #fff;
    padding: 30px 40px;
    border-radius: 15px;
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.25);
    width: 750px;
    text-align: center;
}

/* Heading */
.form-container h2 {
    margin-bottom: 20px;
    font-size: 26px;
    color: black;
}

/* Button Group */
.button-group {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

/* Back Button */
.back-btn {
    background:#E95B5BFF ;
    color: white;
    padding: 12px 20px;
    border-radius: 10px;
    text-decoration: none;
    font-size: 15px;
    font-weight: bold;
}

.back-btn:hover {
    background: #F2D666FF;
}

/* Add Category Button */
.form-container a button {
    background: #E95B5BFF;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    font-size: 16px;
    font-weight: bold;
}

.form-container a button:hover {
    background: #F2D666FF;
}

/* Table */
table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    overflow: hidden;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

table th, table td {
    padding: 14px;
    text-align: center;
    border-bottom: 1px solid #ddd;
    font-size: 15px;
}

table th {
    background: #CBAC24FF;
    color: white;
    font-size: 16px;
    letter-spacing: 0.5px;
}

table tr:nth-child(even) {
    background: #f9f9f9;
}

table tr:hover {
    background: #f1f1f1;
    transform: scale(1.01);
    transition: 0.2s ease-in-out;
}

/* Action Links */
table td a {
    text-decoration: none;
    font-weight: bold;
    padding: 6px 12px;
    border-radius: 6px;
    transition: 0.3s ease;
}

/* Edit Button */
table td a:first-child {
    background: #f39c12;
    color: white;
    margin-right: 6px;
}

table td a:first-child:hover {
    background: #e67e22;
}

/* Delete Button */
table td a:last-child {
    background: #e74c3c;
    color: white;
}

table td a:last-child:hover {
    background: #c0392b;
}

/* Fade-in Animation */
@keyframes fadeIn {
    from {
        opacity: 0;
        transform: translateY(-20px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

    </style>
</head>
<body>
<div class="form-container">
    <h2>Categories</h2>

    <!-- Back & Add Buttons -->
    <div class="button-group">
        <a href="admin_dashboard.php" class="back-btn">Back</a>
        <a href="add_category.php"><button>Add New Category</button></a>
    </div>

    <table>
        <tr><th>ID</th><th>Name</th><th>Actions</th></tr>
        <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= htmlspecialchars($row['name']) ?></td>
                <td>
                    <a href="edit_category.php?id=<?= $row['id'] ?>">Edit</a>
                    <a href="delete_category.php?id=<?= $row['id'] ?>" onclick="return confirm('Delete this category?')">Delete</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </table>
</div>
</body>
</html>
