<?php
session_start();
$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $otp = trim($_POST['otp']);

    if (isset($_SESSION['reset_otp']) && isset($_SESSION['otp_expire'])) {
        if (time() > $_SESSION['otp_expire']) {
            $message = "OTP expired. Please request again.";
            session_destroy();
        } elseif ($otp == $_SESSION['reset_otp']) {
            header("Location: reset_password.php");
            exit();
        } else {
            $message = "Invalid OTP. Try again.";
        }
    } else {
        $message = "No OTP request found.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Verify OTP</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f6f8;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
            width: 350px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
            color: #333;
        }
        input[type="text"] {
            width: 100%;
    padding: 12px 40px 12px 12px; /* extra space on right for eye */
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 16px;
    background-color: #fff;
    outline: none;
        }
        button {
            width: 100%;
            background: #E95B5BFF;
            border: none;
            padding: 12px;
            color: white;
            font-size: 16px;
            border-radius: 25px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background: #ECE955FF;
        }
        p {
            margin-top: 15px;
            font-size: 14px;
            color: red;
        }
        a.back {
            display: block;
            margin-top: 20px;
            font-size: 14px;
            color: #E95B5BFF;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Enter OTP</h2>
        <form method="POST">
            <input type="text" name="otp" maxlength="6" placeholder="Enter 6-digit OTP" required>
            <button type="submit">Verify OTP</button>
        </form>
        <p><?php echo $message; ?></p>
        <a class="back" href="forgot_password.php">Back</a>
    </div>
</body>
</html>
