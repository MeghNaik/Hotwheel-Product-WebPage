<?php
session_start();
include "db.php"; // DB connection

// Load PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE email=? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res->num_rows > 0) {
        $otp = rand(100000, 999999); // 6-digit OTP
        $_SESSION['reset_email'] = $email;
        $_SESSION['reset_otp'] = $otp;
        $_SESSION['otp_expire'] = time() + 300; // expires in 5 minutes

        // Send OTP via Gmail SMTP
        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host       = 'smtp.gmail.com';
            $mail->SMTPAuth   = true;
            $mail->Username   = 'hotwheelhub95@gmail.com'; 
            $mail->Password   = 'yytx jigl njnm wpxl'; // Gmail App Password
            $mail->SMTPSecure = 'tls';
            $mail->Port       = 587;

            $mail->setFrom('hotwheelhub95@gmail.com', 'Hotwheel Hub');
            $mail->addAddress($email);

            $mail->isHTML(true);
            $mail->Subject = 'Password Reset OTP';
            $mail->Body    = "Your OTP code is: <b>$otp</b> (valid for 5 minutes)";

            $mail->send();
            header("Location: verify_otp.php");
            exit();
        } catch (Exception $e) {
            $message = "Failed to send OTP. Mailer Error: {$mail->ErrorInfo}";
        }
    } else {
        $message = "Email not found.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f4f6f8;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            background: #fff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0px 4px 12px rgba(0,0,0,0.1);
            width: 350px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
            color: black;
        }
        input[type="email"] {
           width: 100%;
    padding: 12px 40px 12px 12px; /* extra space on right for eye */
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 16px;
    background-color: #fff;
    outline: none;
        }
        
        button {
            width: 100%;
            background: #e74c3c;
            border: none;
            padding: 12px;
            color: white;
            font-size: 16px;
            border-radius: 25px;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background: #ECE955FF;
        }
        p {
            margin-top: 15px;
            font-size: 14px;
            color: red;
        }
        a.back {
            display: block;
            margin-top: 20px;
            font-size: 14px;
            color: #E95B5BFF;
            text-decoration: none;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Forgot Password</h2>
        <form method="POST">
            <input type="email" name="email" placeholder="Enter your registered email" required>
            <button type="submit">Send OTP</button>
        </form>
        <p><?php echo $message; ?></p>
        <a class="back" href="login.php">Back to Login</a>
    </div>
</body>
</html>