<?php
session_start();
require 'vendor/autoload.php'; // Stripe SDK
include "db.php";

// Stripe keys
\Stripe\Stripe::setApiKey("sk_test_51S7WaBBgbQgglgvsU8VyjXCLQp58uSr8mgCtF0s6B3AQxfBAG4WDE7d1zJX3QQpOrloLarkLmn24SfF9xHSrLbnS00ZZ0F01ob"); // replace with your secret key

// Example: get cart total from session
$cart = $_SESSION['cart'] ?? [];
$total = 0;

foreach ($cart as $product_id => $qty) {
    $stmt = $conn->prepare("SELECT price FROM products WHERE id=?");
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $stmt->bind_result($price);
    if ($stmt->fetch()) {
        $total += $price * $qty;
    }
    $stmt->close();
}

// Stripe expects amount in cents/paise
$amount = $total * 100;

header('Content-Type: application/json');

$checkout_session = \Stripe\Checkout\Session::create([
    'payment_method_types' => ['card'],
    'line_items' => [[
        'price_data' => [
            'currency' => 'inr',
            'product_data' => [
                'name' => 'HotWheel Order',
            ],
            'unit_amount' => $amount,
        ],
        'quantity' => 1,
    ]],
    'mode' => 'payment',
    'success_url' => 'http://localhost/hotwheel/place_order.php?session_id={CHECKOUT_SESSION_ID}',
    'cancel_url' => 'http://localhost/hotwheel/place_order.php',
]);

echo json_encode(['id' => $checkout_session->id]);
