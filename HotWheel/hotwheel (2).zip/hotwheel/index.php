<?php
include "db.php";
session_start();

// ✅ Category filter
$selected_category_id = isset($_GET['category_id']) ? intval($_GET['category_id']) : 0;

// ✅ Pagination setup
$limit = 6; // products per page
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
if ($page < 1) $page = 1;
$offset = ($page - 1) * $limit;

// Count total products
$count_sql = "SELECT COUNT(*) as total FROM products";
if ($selected_category_id > 0) {
    $count_sql .= " WHERE category_id = $selected_category_id";
}
$count_result = $conn->query($count_sql);
$total_products = ($count_result->num_rows > 0) ? $count_result->fetch_assoc()['total'] : 0;
$total_pages = ceil($total_products / $limit);

// Fetch products with limit
$sql = "SELECT * FROM products";
if ($selected_category_id > 0) {
    $sql .= " WHERE category_id = $selected_category_id";
}
$sql .= " LIMIT $limit OFFSET $offset";
$prod_result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <title>HotWheel</title>
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 0; scroll-behavior: smooth; }

       /* Navbar */
        .navbar {
            background: linear-gradient(to bottom, #E95B5BFF, #F2D666FF);
            display: flex; align-items: center; justify-content: space-between;
            padding: 10px 20px; flex-wrap: wrap; position: relative;
        }
        .navbar-logo img { height: 70px; object-fit:contain; }
        .navbar-links { display: flex; gap: 20px; font-size: 16px; flex-wrap: wrap; position: relative; }
        .navbar-links a { color: black; text-decoration: none; }
        .navbar-links a:hover { color: white; }
        .user-info { display: flex; align-items: center; gap: 12px; font-size: 16px; flex-wrap: wrap; }
        .user-info a { color: black; text-decoration: none; }
        .user-info a:hover { color: white; }
        .menu-toggle { display: none; font-size: 28px; cursor: pointer; background:none; border:none; }

        /* Dropdown */
        .dropdown { position: relative; }
        .dropdown-content {
            display: none;
            position: absolute;
            top: 100%; left: 0;
            background-color: #fff;
            min-width: 180px;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            z-index: 100;
        }
        .dropdown-content a {
            display: block;
            padding: 10px;
            color: black;
            text-decoration: none;
            font-size: 15px;
        }
        .dropdown-content a:hover {
            background: #E95B5BFF; color: white;
        }
        .dropdown:hover .dropdown-content { display: block; }


        /* Swiper slider */
        .swiper { width: 100%; max-width: 100%; height: 250px; margin: 40px auto; }
        .swiper-slide {
            background-position: center; background-size: cover;
            width: 300px; height: 200px; border-radius: 12px;
            overflow: hidden; box-shadow: 0 8px 15px rgba(0,0,0,0.3);
        }
        .swiper-slide img { width: 100%; height: 100%; object-fit: cover; }
        .swiper-button-next, .swiper-button-prev { color: #e95b5b; font-weight: bold; }
        .swiper-pagination-bullet { background: #e95b5b; }

        /* Category Slider */
        .category-wrapper { position: relative; display: flex; align-items: center; margin: 20px 0; }
        .category-slider { display: flex; gap: 15px; overflow-x: auto; scroll-behavior: smooth; scrollbar-width: none; padding: 10px; }
        .category-slider::-webkit-scrollbar { display: none; }
        .category-item {
            flex: 0 0 auto; background-color: #f9f9f9; border: 1px solid #ccc;
            padding: 12px 18px; text-align: center; border-radius: 8px;
            font-weight: bold; text-transform: uppercase; cursor: pointer; min-width: 150px;
        }
        .category-item:hover { background-color: #E95B5BFF; color: white; transform: scale(1.05); border-color: transparent; }
        .category-item a { text-decoration: none; color: inherit; display: block; }
        .cat-btn {
            position: absolute; top: 50%; transform: translateY(-50%);
            background: #E95B5BFF; color: white; border: none;
            padding: 12px 18px; border-radius: 50%; cursor: pointer;
            font-size: 18px; z-index: 10;
        }
        .cat-btn:hover { background: #F2D666FF; color: black; }
        .cat-btn.left { left: 0; }
        .cat-btn.right { right: 0; }

        /* Products */
        .products { 
            display: flex; 
            flex-wrap: wrap; 
            gap: 15px; 
            justify-content: center; 
        }

        .product-card {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            padding: 15px; 
            background-color: white; 
            border-radius: 8px;
            box-sizing: border-box; 
            width: 220px; 
            min-height: 450px;
            text-align: center; 
            border: 4px solid transparent;
            border-image: linear-gradient(112deg, black, white, black) 1;
        }

        .product-card h3 { min-height: 50px; font-size: 18px; margin: 10px 0; }
        .product-card p { flex-grow: 1; margin: 6px 0; min-height: 40px; }
        .product-card img { width: 100%; height: 180px; object-fit: contain; background-color: white; padding: 5px; border-radius: 6px; }

        .product-btn {
            display: inline-block; padding: 10px 15px; margin-top: 10px;
            background: #E95B5BFF; color: white; border: none;
            border-radius: 6px; cursor: pointer; text-decoration: none;
        }
        .product-btn:hover { background: #F2D666FF; color: white; }

        /* Pagination */
        .pagination { display: flex; justify-content: center; margin: 20px 0; gap: 8px; flex-wrap: wrap; }
        .pagination a {
           background: #E95B5BFF ;padding: 8px 14px; border: 1px solid #ccc; border-radius: 6px;
            text-decoration: none; color: white; font-weight: bold;
        }
        .pagination a.active { background: #E95B5BFF; color: white; }
        .pagination a:hover { background: #F2D666FF; color: white; }

        /* Footer */
        .footer { background: linear-gradient(to bottom, #F2D666FF, #E95B5BFF); color: black; padding: 40px 20px; margin-top: 40px; }
        .footer-container { display: flex; flex-wrap: wrap; justify-content: space-between; max-width: 1200px; margin: auto; }
        .footer-box { flex: 1 1 200px; margin: 10px 20px; }
        .footer-box h3 { font-size: 20px; margin-bottom: 10px; }
        .footer-box p, .footer-box li { font-size: 16px; line-height: 1.6; }
        .footer-box ul { list-style: none; padding: 0; }
        .footer-box ul li a { text-decoration: none; color: black; }
        .footer-box ul li a:hover { color: white; }
        .footer-socials { display: flex; gap: 15px; margin-top: 10px; }
        .footer-socials img { width: 28px; height: 28px; transition: transform 0.3s ease; }
        .footer-socials img:hover { transform: scale(1.1); }
        .footer-bottom { text-align: center; padding-top: 20px; border-top: 1px solid #444; margin-top: 30px; }
        .footer-bottom p { margin: 0; color: black; }

        /* Scroll to Top */
        #scrollTopBtn {
            position: fixed; bottom: 25px; right: 25px;
            background: #E95B5BFF; color: white;
            border: none; padding: 12px 16px; border-radius: 50%;
            font-size: 20px; cursor: pointer; display: none;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            z-index: 99;
        }
        #scrollTopBtn:hover { background: #F2D666FF; color: black; }

   /* Contact Form */
        .contact-container {
            max-width: 600px;
            margin: 40px auto;
            background: #fff;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        .contact-container h2 {
            margin-top: 0;
            text-align: center;
            color: red;
        }
        .contact-container label { font-weight: bold; display: block; margin-bottom: 6px; }
        .contact-container input,
        .contact-container textarea {
            width: 100%; padding: 12px; margin-bottom: 10px;
            border: 1px solid #ccc; border-radius: 8px;
            font-size: 15px; box-sizing: border-box;
        }
        .error { color: red; font-size: 13px; display: none; margin-bottom: 10px; }
        .success { color: green; font-weight: bold; text-align: center; }
        .contact-container button {
            width: 100%; padding: 12px;
            background: #E95B5BFF; border: none;
            color: white; border-radius: 6px;
            font-size: 16px; cursor: pointer;
        }
        .contact-container button:hover { background: #F2D666FF; }
        /* Cart badge styling */
.cart-link {
    position: relative;
    display: inline-block;
}

.cart-count {
    background: red;
    color: white;
    font-size: 14px;
    font-weight: bold;
    padding: 2px 8px;
    border-radius: 50%;
    margin-left: 5px;
    display: inline-block;
    animation: pop 0.5s ease;
}
/* Bounce/Pop animation */
@keyframes pop {
    0% { transform: scale(0.5); opacity: 0; }
    50% { transform: scale(1.3); opacity: 1; }
    100% { transform: scale(1); }
}
        /* Responsive */
        @media (max-width: 1024px) {
            .products { justify-content: center; }
        }

        @media (max-width: 768px) {
            .navbar-links {
                display: none;
                flex-direction: column;
                width: 100%;
                background: #f2d666;
                padding: 10px;
                border-radius: 6px;
                margin-top: 10px;
            }
            .navbar-links.active { display: flex; }
            .menu-toggle { display: block; }
            .category-item { min-width: 120px; font-size: 14px; padding: 10px; }
            .product-card { width: 45%; }
        }

        @media (max-width: 480px) {
            .navbar-logo img { height: 55px; }
            .product-card { width: 100%; }
        }
    </style>
</head>
<body>
<!-- Navbar -->
<div class="navbar">
    <div class="navbar-logo">
        <a href="index.php"><img src="images/ht.png" alt="Logo"></a>    
    </div>
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    <div class="navbar-links" id="menuLinks">
        <a href="index.php">Home</a>
        <!-- ✅ Cart with count (only show number if > 0) -->
        <?php
        $cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
        ?>
        <a href="cart.php" class="cart-link">
            Cart 
            <?php if ($cart_count > 0): ?>
                <span class="cart-count"><?= $cart_count ?></span>
            <?php endif; ?>
        </a>
           <a href="wishlist.php">Wishlist</a>
           <a href="products.php">Products</a>

        <!-- ✅ Categories Dropdown -->
        <div class="dropdown">
            <a href="javascript:void(0)">Categories ▾</a>
            <div class="dropdown-content">
                <?php
                $cat_result = $conn->query("SELECT * FROM categories");
                if ($cat_result->num_rows > 0) {
                    while ($row = $cat_result->fetch_assoc()) {
                        echo "<a href='index.php?category_id=" . $row['id'] . "#categories'>" . htmlspecialchars($row['name']) . "</a>";
                    }
                } else {
                    echo "<a href='#'>No Categories</a>";
                }
                ?>
            </div>
        </div>

        <!-- ✅ Contact Us scroll -->
        <a href="#contactSection">Contact Us</a>
    </div>
    <div class="user-info">
        <?php
        if (isset($_SESSION['username'])) {
            echo "<a href='#'>Welcome, " . htmlspecialchars($_SESSION['username']) . "</a>";
            echo "<a href='logout.php'>Logout</a>";
        } else {
            echo "<a href='login.php'>Login</a>";
        }
        ?>
    </div>
</div>


<!-- Swiper Slider -->
<div class="swiper mySwiper">
  <div class="swiper-wrapper">
    <div class="swiper-slide"><img src="images/slide11.jpeg" alt="1"></div>
    <div class="swiper-slide"><img src="images/slide2.jpeg" alt="2"></div>
    <div class="swiper-slide"><img src="images/slide3.jpeg" alt="3"></div>
    <div class="swiper-slide"><img src="images/slide4.jpeg" alt="4"></div>
    <div class="swiper-slide"><img src="images/slide5.jpeg" alt="5"></div>
    <div class="swiper-slide"><img src="images/slide6.jpeg" alt="6"></div>
    <div class="swiper-slide"><img src="images/slide7.jpeg" alt="7"></div>
    <div class="swiper-slide"><img src="images/slide8.jpeg" alt="8"></div>
    <div class="swiper-slide"><img src="images/slide9.jpeg" alt="9"></div>
    <div class="swiper-slide"><img src="images/slide10.jpeg" alt="10"></div>
  </div>
  <div class="swiper-button-next"></div>
  <div class="swiper-button-prev"></div>
  <div class="swiper-pagination"></div>
</div>

<div class="container">
    <h1 style="text-align:center; color:Red;">Categories</h2>
    <div class="category-wrapper">
        <button class="cat-btn left" onclick="scrollCategories(-300)">&#10094;</button>
        <div class="category-slider" id="categorySlider">
            <?php
            $cat_result = $conn->query("SELECT * FROM categories");
            if ($cat_result->num_rows > 0) {
                while ($row = $cat_result->fetch_assoc()) {
                    $active = ($row['id'] == $selected_category_id) ? "style='background:#E95B5BFF; color:white;'" : "";
                    echo "<div class='category-item' $active><a href='index.php?category_id=" . $row['id'] . "'>" . htmlspecialchars($row['name']) . "</a></div>";
                }
            } else {
                echo "<p>No categories available.</p>";
            }
            ?>
        </div>
        <button class="cat-btn right" onclick="scrollCategories(300)">&#10095;</button>
    </div>

    <h1 style="text-align:center; color:red;">Products</h2>
    <div class="products">
        <?php
        if ($prod_result->num_rows > 0) {
            while ($product = $prod_result->fetch_assoc()) {
                echo "<div class='product-card'>";
                echo "<img src='uploads/" . htmlspecialchars($product['image']) . "' alt='Product Image'>";
                echo "<h3>" . htmlspecialchars($product['name']) . "</h3>";
                echo "<p>" . (!empty($product['description']) ? htmlspecialchars($product['description']) : 'No details available') . "</p>";
                echo "<p><strong>₹" . htmlspecialchars($product['price']) . "</strong></p>";
                echo "<a href='product_detail.php?id=" . $product['id'] . "' class='product-btn'>Click To Buy</a>";
                echo "</div>";
            }
        } else {
            echo "<p>No products available.</p>";
        }
        ?>
    </div>

    <!-- Pagination -->
    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?category_id=<?= $selected_category_id ?>&page=<?= $page-1 ?>">Prev</a>
        <?php endif; ?>

        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <a href="?category_id=<?= $selected_category_id ?>&page=<?= $i ?>" class="<?= ($i == $page) ? 'active' : '' ?>"><?= $i ?></a>
        <?php endfor; ?>

        <?php if ($page < $total_pages): ?>
            <a href="?category_id=<?= $selected_category_id ?>&page=<?= $page+1 ?>">Next</a>
        <?php endif; ?>
    </div>
</div>
<!-- ✅ Contact Section -->
<div class="contact-container" id="contactSection">
    <h2>Contact Us</h2>
    <form id="contactForm">
        <label>Name:</label>
        <input type="text" name="name" id="name" required>
        <div class="error" id="nameError">Name must be at least 3 characters.</div>

        <label>Email:</label>
        <input type="email" name="email" id="email" required>
        <div class="error" id="emailError">Enter a valid email address.</div>

        <label>Message:</label>
        <textarea name="message" id="message" required></textarea>
        <div class="error" id="messageError">Message must be at least 10 characters.</div>

        <button type="submit">Send</button>
    </form>
    <div id="formMessage"></div>
</div>

<!-- ✅ jQuery CDN -->
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<!-- ✅ Live Validation + AJAX -->
<script>
function validateName() {
    let name = $("#name").val().trim();
    if (name.length < 3) {
        $("#nameError").show();
        return false;
    } else {
        $("#nameError").hide();
        return true;
    }
}

function validateEmail() {
    let email = $("#email").val().trim();
    let regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!regex.test(email)) {
        $("#emailError").show();
        return false;
    } else {
        $("#emailError").hide();
        return true;
    }
}

function validateMessage() {
    let message = $("#message").val().trim();
    if (message.length < 10) {
        $("#messageError").show();
        return false;
    } else {
        $("#messageError").hide();
        return true;
    }
}

// ✅ Live validation on typing
$("#name").on("input", validateName);
$("#email").on("input", validateEmail);
$("#message").on("input", validateMessage);

// ✅ Form Submit with AJAX
$("#contactForm").on("submit", function(e) {
    e.preventDefault();

    if (validateName() & validateEmail() & validateMessage()) {
        $.ajax({
            type: "POST",
            url: "contact_process.php",
            data: $(this).serialize(),
            success: function(response) {
                console.log("Server Response: ", response);

                if (response.trim() === "success") {
                    $("#formMessage").html("<p style='color: green;'>Message sent successfully!</p>");
                    $("#contactForm")[0].reset();
                } else {
                    $("#formMessage").html("<p style='color: red;'>Error: " + response + "</p>");
                }
            },
            error: function(xhr, status, error) {
                console.error("AJAX Error: ", error);
                $("#formMessage").html("<p style='color: red;'>AJAX request failed: " + error + "</p>");
            }
        });
    }
});
</script>

<footer class="footer">
  <div class="footer-container">
    <div class="footer-box">
      <h3>About Us</h3>
      <p>HotWheel Hub is your one-stop shop for authentic HotWheels collectible cars. Whether you're a hobbyist or a hardcore collector, we bring you rare and classic models at your fingertips.</p>
    </div>
    <div class="footer-box">
      <h3>Contact Us</h3>
      <p>Email: hotwheelhub95.com</p>
    </div>
    <div class="footer-box">
      <h3>Legal</h3>
      <ul>
        <li><a href="privacy.php">Privacy Policy</a></li>
        <li><a href="terms.php">Terms of Service</a></li>
      </ul>
    </div>
    <div class="footer-box">
      <h3>Follow Us</h3>
      <div class="footer-socials">
        <a href="#"><img src="images/instagram.png" alt="Instagram"></a>
        <a href="#"><img src="images/Facebook.png" alt="Facebook"></a>
        <a href="#"><img src="images/X.png" alt="Twitter"></a>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; 2025 HotWheel Store. All rights reserved.</p>
  </div>
</footer>

<!-- Scroll to Top Button -->
<button id="scrollTopBtn" onclick="scrollToTop()">&#8679;</button>

<!-- Swiper JS -->
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
<script>
const swiper = new Swiper(".mySwiper", {
  effect: "coverflow",
  grabCursor: true,
  centeredSlides: true,
  loop: true,
  slidesPerView: "auto",
  coverflowEffect: { rotate: 30, stretch: 0, depth: 150, modifier: 1, slideShadows: true },
  autoplay: { delay: 2500, disableOnInteraction: false },
  pagination: { el: ".swiper-pagination", clickable: true },
  navigation: { nextEl: ".swiper-button-next", prevEl: ".swiper-button-prev" },
});

// Scroll categories
function scrollCategories(amount) {
    document.getElementById("categorySlider").scrollBy({ left: amount, behavior: "smooth" });
}

// Scroll to Top
let scrollBtn = document.getElementById("scrollTopBtn");
window.onscroll = function() {
    if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
        scrollBtn.style.display = "block";
    } else {
        scrollBtn.style.display = "none";
    }
};
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
}

// Toggle menu
function toggleMenu() {
    document.getElementById("menuLinks").classList.toggle("active");
}
</script>
</body>
</html>
