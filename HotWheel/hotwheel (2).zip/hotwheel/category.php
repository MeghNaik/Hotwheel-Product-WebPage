<?php
include "db.php";

if (!isset($_GET['id'])) {
    echo "Category not selected.";
    exit();
}

$category_id = intval($_GET['id']);
$category = $conn->query("SELECT * FROM categories WHERE id = $category_id")->fetch_assoc();
$products = $conn->query("SELECT * FROM products WHERE category_id = $category_id");
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= $category['name'] ?> Products</title>    <style>
        .product-box {
            border: 1px solid #ccc;
            border-radius: 8px;
            margin: 10px;
            padding: 10px;
            width: 220px;
            float: left;
            text-align: center;
        }
        .product-box img {
            width: 100%;
            height: 180px;
            object-fit: cover;
            border-radius: 6px;
        }
        .product-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2><?= htmlspecialchars($category['name']) ?> Products</h2>
    <div class="product-container">
        <?php while($row = $products->fetch_assoc()): ?>
            <div class="product-box">
                <img src="uploads/<?= $row['image'] ?>" alt="<?= $row['name'] ?>">
                <h4><?= htmlspecialchars($row['name']) ?></h4>
                <p>₹<?= $row['price'] ?></p>
                <p><a href="product_detail.php?id=<?= $row['id'] ?>">View Details</a></p>
            </div>
        <?php endwhile; ?>
    </div>
</div>

</body>
</html>
