<?php
session_start();
include "db.php";

// Handle filter and sorting inputs safely
$sort = isset($_GET['sort']) ? $_GET['sort'] : '';
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$colors = isset($_GET['colors']) && is_array($_GET['colors']) ? $_GET['colors'] : [];

$min_price = isset($_GET['min_price']) && $_GET['min_price'] !== '' ? intval($_GET['min_price']) : null;
$max_price = isset($_GET['max_price']) && $_GET['max_price'] !== '' ? intval($_GET['max_price']) : null;

// Build filters
$where = [];

// ✅ Search filter (strictly name, description, category)
if ($search !== '') {
    $search_esc = $conn->real_escape_string($search);
    $where[] = "(p.name LIKE '%$search_esc%' 
                 OR p.description LIKE '%$search_esc%' 
                 OR c.name LIKE '%$search_esc%')";
}

// ✅ Multiple color filter with checkboxes
if (!empty($colors)) {
    $color_conditions = [];
    foreach ($colors as $color) {
        $color_esc = $conn->real_escape_string($color);
        $color_conditions[] = "p.description LIKE '%$color_esc%'";
    }
    $where[] = "(" . implode(" OR ", $color_conditions) . ")";
}

// ✅ Price filter (exact match, no partial ranges)
$valid_price_filter = true;

if ($min_price !== null && $max_price !== null && $max_price >= $min_price) {
    // Range filter
    $check_price = $conn->query("SELECT COUNT(*) AS cnt FROM products WHERE price BETWEEN $min_price AND $max_price");
    $count_price = $check_price ? intval($check_price->fetch_assoc()['cnt']) : 0;
    if ($count_price > 0) {
        $where[] = "p.price BETWEEN $min_price AND $max_price";
    } else {
        $valid_price_filter = false;
    }
} elseif ($min_price !== null && $max_price === null) {
    // ✅ Exact match instead of >=
    $check_price = $conn->query("SELECT COUNT(*) AS cnt FROM products WHERE price = $min_price");
    $count_price = $check_price ? intval($check_price->fetch_assoc()['cnt']) : 0;
    if ($count_price > 0) {
        $where[] = "p.price = $min_price";
    } else {
        $valid_price_filter = false;
    }
} elseif ($max_price !== null && $min_price === null) {
    // ✅ Exact match instead of <=
    $check_price = $conn->query("SELECT COUNT(*) AS cnt FROM products WHERE price = $max_price");
    $count_price = $check_price ? intval($check_price->fetch_assoc()['cnt']) : 0;
    if ($count_price > 0) {
        $where[] = "p.price = $max_price";
    } else {
        $valid_price_filter = false;
    }
}

$where_sql = (count($where) && $valid_price_filter) ? "WHERE " . implode(" AND ", $where) : "";
if (!$valid_price_filter) {
    // No products in price range → force empty result
    $where_sql = "WHERE 1=0";
}


// Sorting
$order_sql = "ORDER BY p.id DESC";
if ($sort == "price_low") $order_sql = "ORDER BY p.price ASC";
elseif ($sort == "price_high") $order_sql = "ORDER BY p.price DESC";
elseif ($sort == "name_asc") $order_sql = "ORDER BY p.name ASC";
elseif ($sort == "name_desc") $order_sql = "ORDER BY p.name DESC";

// Pagination
$limit = 8;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $limit;

// Get total products
$total_result = $conn->query("
    SELECT COUNT(*) AS total 
    FROM products p 
    JOIN categories c ON p.category_id = c.id 
    $where_sql
");
$total_products = $total_result ? ($total_result->fetch_assoc()['total'] ?? 0) : 0;
$total_pages = ceil($total_products / $limit);

// Fetch products
$sql = "
    SELECT p.*, c.name AS category_name 
    FROM products p 
    JOIN categories c ON p.category_id = c.id 
    $where_sql 
    $order_sql 
    LIMIT $limit OFFSET $offset
";
$result = $conn->query($sql);
?>



<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Products</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
/* Reset */
body { margin: 0; font-family: Arial, sans-serif; background: #fafafa; }
a { text-decoration: none; }

/* Navbar */
.navbar {
    background: linear-gradient(to bottom, #E95B5BFF, #F2D666FF);
    display: flex; align-items: center; justify-content: space-between;
    padding: 10px 20px; flex-wrap: wrap; position: relative;
}
.navbar-logo img { height: 70px; object-fit: contain; }
.navbar-links { display: flex; gap: 20px; font-size: 16px; flex-wrap: wrap; position: relative; }
.navbar-links a { color: black; text-decoration: none; }
.navbar-links a:hover { color: white; }
.user-info { display: flex; align-items: center; gap: 12px; font-size: 16px; flex-wrap: wrap; }
.user-info a { color: black; text-decoration: none; }
.user-info a:hover { color: white; }
.menu-toggle { display: none; font-size: 28px; cursor: pointer; background:none; border:none; }

/* Dropdown */
.dropdown { position: relative; }
.dropdown-content {
    display: none;
    position: absolute;
    top: 100%; left: 0;
    background-color: #fff;
    min-width: 180px;
    border-radius: 6px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    z-index: 100;
}
.dropdown-content a {
    display: block;
    padding: 10px;
    color: black;
    text-decoration: none;
    font-size: 15px;
}
.dropdown-content a:hover {
    background: #E95B5BFF; color: white;
}
.dropdown:hover .dropdown-content { display: block; }

/* Layout container */
.container {
    display: flex;
    flex-wrap: nowrap;
    min-height: 100vh;
    gap: 20px;
    padding: 20px;
}

/* Sidebar */
.sidebar {
    width: 260px;
    background: #fff;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 2px 2px 8px rgba(0,0,0,0.1);
    flex-shrink: 0;
    height: fit-content;
}
.sidebar h3 { margin-top: 0; }
.sidebar label { display: block; margin-top: 10px; font-size: 14px; font-weight: bold; }
.sidebar input {
    width: 100%; padding: 8px 1px; margin-top: 4px;
    border: 1px solid #ccc; border-radius: 6px;
}
.sidebar button {
    margin-top: 15px; width: 100%; padding: 10px;
    background: #E95B5BFF; border: none; color: #fff;
    font-size: 15px; border-radius: 6px; cursor: pointer;
}
.sidebar button:hover { background: #ECE955FF; color: white; }

/* Checkbox group */
.checkbox-group {
    display: flex;
    flex-direction: column;
    gap: 8px;
    margin-top: 8px;
}
.checkbox-item { position: relative; padding-left: 28px; cursor: pointer; font-size: 14px; user-select: none; color: #333; line-height: 18px; }
.checkbox-item input { position: absolute; opacity: 0; cursor: pointer; }
.checkbox-item .checkmark { position: absolute; top: 0; left: 0; height: 18px; width: 18px; border: 2px solid #ccc; border-radius: 4px; background-color: white; }
.checkbox-item:hover .checkmark { border-color: #E95B5BFF; }
.checkbox-item input:checked ~ .checkmark { background-color: #E95B5BFF; border-color: #E95B5BFF; }
.checkbox-item .checkmark:after { content: ""; position: absolute; display: none; }
.checkbox-item input:checked ~ .checkmark:after { display: block; }
.checkbox-item .checkmark:after { left: 5px; top: 1px; width: 4px; height: 9px; border: solid white; border-width: 0 2px 2px 0; transform: rotate(45deg); }

/* Main content */
.main { flex: 1; }
.top-bar { display: flex; justify-content: flex-end; margin-bottom: 20px; }
.top-bar select { padding: 8px; border-radius: 6px; }

/* Product grid */
.product-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 20px;
}
.product-card {
    background: #fff; border-radius: 12px; padding: 15px;
    text-align: center; display: flex; flex-direction: column;
}
.product-card img {
    width: 100%; height: 200px; object-fit: contain;
}
.product-card h3 { font-size: 18px; margin: 10px 0; }
.product-card p { font-size: 14px; margin: 3px 0; color: #666; }
.price { font-size: 18px; font-weight: bold; color: #E95B5BFF; }
.btn { margin-top: auto; background: #E95B5BFF; padding: 8px 12px; color: white; border-radius: 6px; font-size: 14px; }
.btn:hover { background: #ECE955FF; color: white; }

/* Pagination */
.pagination { text-align: center; margin-top: 30px; }
.pagination a { margin: 0 4px; padding: 8px 12px; border-radius: 6px; background: #E95B5BFF; color: white; }
.pagination a.active { background: #E95B5BFF; color: white; }
.pagination a:hover { background: #F2D666FF; }

/* Footer */
.footer {
    background: linear-gradient(to bottom, #F2D666FF, #E95B5BFF);
    color: black;
    padding: 40px 20px;
    margin-top: 2%;
}
.footer-container {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    max-width: 1200px;
    margin: auto;
}
.footer-box { flex: 1 1 200px; margin: 10px 20px; }
.footer-box h3 { font-size: 20px; margin-bottom: 10px; }
.footer-box p, .footer-box li { font-size: 16px; line-height: 1.6; }
.footer-box ul { list-style: none; padding: 0; }
.footer-box ul li a { text-decoration: none; color: black; }
.footer-box ul li a:hover { color: white; }
.footer-socials { display: flex; gap: 15px; margin-top: 10px; }
.footer-socials img { width: 28px; height: 28px; transition: transform 0.3s ease; }
.footer-socials img:hover { transform: scale(1.1); }
.footer-bottom { text-align: center; padding-top: 20px; border-top: 1px solid #444; margin-top: 30px; }
.footer-bottom p { margin: 0; color: black; }

/* Scroll to Top */
#scrollTopBtn {
    position: fixed; bottom: 25px; right: 25px;
    background: #E95B5BFF; color: white;
    border: none; padding: 12px 16px; border-radius: 50%;
    font-size: 20px; cursor: pointer; display: none;
    box-shadow: 0 4px 8px rgba(0,0,0,0.3);
    z-index: 99;
}
#scrollTopBtn:hover { background: #F2D666FF; color: black; }

/* Bounce/Pop animation */
@keyframes pop {
    0% { transform: scale(0.5); opacity: 0; }
    50% { transform: scale(1.3); opacity: 1; }
    100% { transform: scale(1); }
}


</style>
</head>
<body>
<!-- Navbar -->
<div class="navbar">
    <div class="navbar-logo">
        <a href="index.php"><img src="images/ht.png" alt="Logo"></a>    
    </div>
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    <div class="navbar-links" id="menuLinks">
        <a href="index.php">Home</a>
        <?php
        $cart_count = isset($_SESSION['cart']) ? count($_SESSION['cart']) : 0;
        ?>
        <a href="cart.php" class="cart-link">
            Cart 
            <?php if ($cart_count > 0): ?>
                <span class="cart-count"><?= $cart_count ?></span>
            <?php endif; ?>
        </a>
        <a href="wishlist.php">Wishlist</a>
        <a href="products.php">Products</a>

        <div class="dropdown">
            <a href="javascript:void(0)">Categories ▾</a>
            <div class="dropdown-content">
                <?php
                $cat_result = $conn->query("SELECT * FROM categories");
                if ($cat_result->num_rows > 0) {
                    while ($row = $cat_result->fetch_assoc()) {
                        echo "<a href='index.php?category_id=" . $row['id'] . "#categories'>" . htmlspecialchars($row['name']) . "</a>";
                    }
                } else {
                    echo "<a href='#'>No Categories</a>";
                }
                ?>
            </div>
        </div>
        <a href="index.php#contactSection">Contact Us</a>
    </div>
    <div class="user-info">
        <?php
        if (isset($_SESSION['username'])) {
            echo "<a href='#'>Welcome, " . htmlspecialchars($_SESSION['username']) . "</a>";
            echo "<a href='logout.php'>Logout</a>";
        } else {
            echo "<a href='login.php'>Login</a>";
        }
        ?>
    </div>
</div>
<div class="container">
    <!-- Sidebar -->
    <div class="sidebar">
        <h3>Filters</h3>
        <form method="get">
            <label>Search by Name</label>
            <input type="text" name="search" value="<?= htmlspecialchars($search) ?>">

            <!-- ✅ Color checkboxes -->
           <label>Color</label>
<div class="checkbox-group">
    <?php 
    $available_colors = ["Red","Blue","Green","Black","White","Yellow"];
    foreach ($available_colors as $c) {
        $checked = in_array($c, $colors) ? "checked" : "";
        echo "<label class='checkbox-item'>
                <input type='checkbox' name='colors[]' value='".htmlspecialchars($c)."' $checked>
                <span class='checkmark'></span> $c
              </label>";
    }
    ?>
</div><br>
            <label>Min Price</label>
            <input type="number" name="min_price" value="<?= htmlspecialchars($min_price) ?>">
            <label>Max Price</label>
            <input type="number" name="max_price" value="<?= htmlspecialchars($max_price) ?>">

            <!-- ✅ Preserve sort value -->
            <input type="hidden" name="sort" value="<?= htmlspecialchars($sort) ?>">

            <button type="submit">Apply Filter</button>
        </form>
    </div>

    <!-- Main content -->
    <div class="main">
        <div class="top-bar">
            <form method="get">
                <input type="hidden" name="search" value="<?= htmlspecialchars($search) ?>">
                <?php foreach ($colors as $c): ?>
                    <input type="hidden" name="colors[]" value="<?= htmlspecialchars($c) ?>">
                <?php endforeach; ?>
                <input type="hidden" name="min_price" value="<?= htmlspecialchars($min_price) ?>">
                <input type="hidden" name="max_price" value="<?= htmlspecialchars($max_price) ?>">

                <label>Sort By: </label>
                <select name="sort" onchange="this.form.submit()">
                    <option value="">Default</option>
                    <option value="price_low" <?= $sort=='price_low'?'selected':'' ?>>Price: Low to High</option>
                    <option value="price_high" <?= $sort=='price_high'?'selected':'' ?>>Price: High to Low</option>
                    <option value="name_asc" <?= $sort=='name_asc'?'selected':'' ?>>Name: A-Z</option>
                    <option value="name_desc" <?= $sort=='name_desc'?'selected':'' ?>>Name: Z-A</option>
                </select>
            </form>
        </div>

        <div class="product-grid">
            <?php if ($result && $result->num_rows > 0): while($row = $result->fetch_assoc()): ?>
                <div class="product-card">
                    <img src="uploads/<?= htmlspecialchars($row['image']) ?>" alt="">
                    <h3><?= htmlspecialchars($row['name']) ?></h3>
                    <p><?= htmlspecialchars($row['category_name']) ?></p>
                    <p class="price">₹<?= htmlspecialchars($row['price']) ?></p>
                    <a href="product_detail.php?id=<?= $row['id'] ?>" class="btn">View Details</a>
                </div>
            <?php endwhile; else: ?>
                <p>No products found.</p>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <div class="pagination">
        <?php
        $queryParams = $_GET;
        if ($page > 1) { $queryParams['page']=$page-1;
            echo '<a href="?'.http_build_query($queryParams).'">« Prev</a>'; }
        for ($i=1;$i<=$total_pages;$i++) {
            $queryParams['page']=$i;
            $active=$i==$page?'active':''; 
            echo '<a href="?'.http_build_query($queryParams).'" class="'.$active.'">'.$i.'</a>';
        }
        if ($page<$total_pages){ $queryParams['page']=$page+1;
            echo '<a href="?'.http_build_query($queryParams).'">Next »</a>'; }
        ?>
        </div>
    </div>
</div>

<footer class="footer">
  <div class="footer-container">
    <div class="footer-box">
      <h3>About Us</h3>
      <p>HotWheel Hub is your one-stop shop for authentic HotWheels collectible cars. Whether you're a hobbyist or a hardcore collector, we bring you rare and classic models at your fingertips.</p>
    </div>
    <div class="footer-box">
      <h3>Contact Us</h3>
      <p>Email: hotwheelhub95.com</p>
    </div>
    <div class="footer-box">
      <h3>Legal</h3>
      <ul>
        <li><a href="privacy.php">Privacy Policy</a></li>
        <li><a href="terms.php">Terms of Service</a></li>
      </ul>
    </div>
    <div class="footer-box">
      <h3>Follow Us</h3>
      <div class="footer-socials">
        <a href="#"><img src="images/instagram.png" alt="Instagram"></a>
        <a href="#"><img src="images/Facebook.png" alt="Facebook"></a>
        <a href="#"><img src="images/X.png" alt="Twitter"></a>
      </div>
    </div>
  </div>
  <div class="footer-bottom">
    <p>&copy; 2025 HotWheel Store. All rights reserved.</p>
  </div>
</footer>
<button id="scrollTopBtn" onclick="scrollToTop()">&#8679;</button>

<script>
// Toggle menu (navbar)
function toggleMenu() {
    document.getElementById("menuLinks").classList.toggle("active");
}

// Scroll to Top
window.onscroll = function() {
    let btn = document.getElementById("scrollTopBtn");
    if (document.body.scrollTop > 200 || document.documentElement.scrollTop > 200) {
        btn.style.display = "block";
    } else {
        btn.style.display = "none";
    }
};
function scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
</script>


</body>
</html>