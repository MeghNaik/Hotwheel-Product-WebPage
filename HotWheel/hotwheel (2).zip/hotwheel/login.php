<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
<style>
body {
    font-family: Arial, sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh; 
    margin: 0;
    background: #f4f4f4;
}

.form-container {
    background-color: #fff;
    padding: 40px 30px;
    border-radius: 20px;
    box-shadow: 0 15px 30px rgba(0,0,0,0.15);
    width: 380px;
    text-align: center;
}

.form-container h2 {
    margin-bottom: 20px;
    color: #333;
    font-weight: bold;
    font-size: 26px;
}

/* Apply same styles for all input types */
input[type="email"], 
input[type="password"], 
input[type="text"] {
    width: 100%;
    padding: 12px 40px 12px 12px; /* extra space on right for eye */
    margin: 10px 0;
    border: 1px solid #ccc;
    border-radius: 8px;
    box-sizing: border-box;
    font-size: 16px;
    background-color: #fff;
    outline: none;
}

.password-container {
    position: relative;
}
.toggle-password {
    position: absolute;
    right: 12px;
    top: 50%;
    transform: translateY(-50%);
    cursor: pointer;
    font-size: 18px;
    color: #888;
    user-select: none;
    width: 24px; 
    text-align: center;
}
.toggle-password:hover {
    color: #f5576c;
}

#message {
    margin-top: 8px;
    font-size: 14px;
    min-height: 18px;
}
.success { color: #2e7d32; }
.error { color: #c62828; }

.button-group {
    display: flex;
    justify-content: space-between;
    margin-top: 25px;
    gap: 12px;
}
.button-group button, .button-group .register-btn {
    flex: 1;
    padding: 14px;
    border-radius: 25px;
    font-weight: bold;
    font-size: 16px;
    text-align: center;
    cursor: pointer;
    border: none;
    text-decoration: none;
    color: #fff;
    background:#E95B5BFF;
}
.button-group button:hover, .button-group .register-btn:hover {
    background: #ECE955FF;
    color: white;
}

.forgot {
    display: block;
    margin-top: 15px;
    font-size: 14px;
    color: #555;
    text-decoration: none;
}
.forgot:hover {
    color: #f5576c;
}
</style>
</head>
<body>
<div class="form-container">
    <h2>User Login</h2>
    <form id="loginForm" method="post">
        <input type="email" name="email" id="email" placeholder="Email" required>

        <div class="password-container">
            <input type="password" name="password" id="password" placeholder="Password" required>
            <span class="toggle-password" id="togglePass">👁</span>
        </div>

        <div id="message"></div>

        <div class="button-group">
            <button type="submit">Login</button>
            <a href="register.php" class="register-btn">Register</a>
        </div>

        <a href="forgot_password.php" class="forgot">Forgot Password?</a>
    </form>
</div>

<script>
// toggle password
document.getElementById("togglePass").addEventListener("click", function(){
    const pass = document.getElementById("password");
    if (pass.type === "password") {
        pass.type = "text";
    } else {
        pass.type = "password";
    }
});

// handle login
document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("loginForm");
    const message = document.getElementById("message");
    const emailInput = document.getElementById("email");
    const passInput = document.getElementById("password");

    // --- Live Validation ---
    function validateFields() {
        const email = emailInput.value.trim();
        const password = passInput.value.trim();

        if (email !== "" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            message.className = "error";
            message.textContent = "Please enter a valid email address.";
            return false;
        } else if (password !== "" && password.length < 6) {
            message.className = "error";
            message.textContent = "Password must be at least 6 characters.";
            return false;
        } else {
            message.className = "";
            message.textContent = "";
            return true;
        }
    }

    // Run validation while typing
    emailInput.addEventListener("input", validateFields);
    passInput.addEventListener("input", validateFields);

    // Form submit
    form.addEventListener("submit", function(e) {
        e.preventDefault();

        if (!validateFields()) return; // stop if invalid

        const formData = new FormData(form);

        fetch("login_action.php", {
            method: "POST",
            body: formData,
            credentials: "same-origin"
        })
        .then(res => res.text())
        .then(data => {
            if (data.trim() === "success") {
                message.className = "success";
                message.textContent = "Login successful. Redirecting…";
                setTimeout(() => window.location.href = "dashboard.php", 1000);
            } else {
                message.className = "error";
                message.textContent = data;
            }
        })
        .catch(() => {
            message.className = "error";
            message.textContent = "Network error. Please try again.";
        });
    });
});
</script>

</body>
</html>
