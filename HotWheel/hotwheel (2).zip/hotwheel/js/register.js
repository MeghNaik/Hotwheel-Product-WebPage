document.getElementById("registerForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const form = e.target;
    const formData = new FormData(form);
    const message = document.getElementById("message");

    fetch("register_action.php", {
        method: "POST",
        body: formData
    })
    .then(res => res.text())
    .then(data => {
        if (data === "success") {
            message.style.color = "green";
            message.innerText = "Registration successful!";
            form.reset();
        } else {
            message.style.color = "red";
            message.innerText = data;
        }
    });
});
