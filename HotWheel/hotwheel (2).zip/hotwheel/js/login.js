document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const message = document.getElementById("message");
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value.trim();

    // Live validation
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        message.className = "error";
        message.textContent = "Please enter a valid email address.";
        return;
    }
    if (password.length < 6) {
        message.className = "error";
        message.textContent = "Password must be at least 6 characters.";
        return;
    }

    const formData = new FormData(this);

    fetch("login_action.php", {
        method: "POST",
        body: formData,
        credentials: "same-origin"
    })
    .then(res => res.text())
    .then(data => {
        if (data === "success") {
            message.className = "success";
            message.textContent = "Login successful. Redirecting…";
            window.location.href = "dashboard.php";
        } else {
            message.className = "error";
            message.textContent = data;
        }
    })
    .catch(() => {
        message.className = "error";
        message.textContent = "Network error. Please try again.";
    });
});
