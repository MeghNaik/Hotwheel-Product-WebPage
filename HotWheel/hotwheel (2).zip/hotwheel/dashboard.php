<?php
session_start();

// Check if user is logged in
if (!isset($_SESSION['username']) || !isset($_SESSION['role'])) {
    // Redirect to login page if not logged in
    header("Location: login.php");
    exit();
}

// Assign session values
$username = $_SESSION['username'];
$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <style>
       body {
            font-family: 'Segoe UI', sans-serif;
    background: #f2f2f2;
    margin: 0;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
}

/* Dashboard Card */
.card {
    background: #ffffff;
    padding: 40px 30px;
    max-width: 400px;
    width: 90%;
    border-radius: 12px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
    text-align: center;
    animation: fadeIn 0.5s ease-in-out;
}

/* Welcome Message */
.card h2 {
    font-size: 24px;
    color: #333;
    margin-bottom: 20px;
}

/* Links */
.card a {
    display: inline-block;
    margin: 10px 0;
    padding: 10px 20px;
    text-decoration: none;
    background-color: #E95B5BFF;
    color: white;
    border-radius: 6px;
    transition: background 0.3s;
    font-weight: 500;
}

.card a:hover {
   background: #ECE955FF;
}

/* Optional Fade In Animation */
@keyframes fadeIn {
    from { opacity: 0; transform: translateY(10px); }
    to { opacity: 1; transform: translateY(0); }
}

    </style>
</head>
<body>
    <div class="card">
        <h2>Welcome, <strong><?php echo htmlspecialchars($username); ?></strong>!</h2>        
        <a href="logout.php">Logout</a><br><br>
        <a href="index.php">Click Here To Visit Our Website</a>

    </div>
</body>
</html>
